import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Lazy initialization of Gemini as instructed
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      console.warn("GEMINI_API_KEY process env is missing. Falling back to offline engine.");
    }
    aiClient = new GoogleGenAI({
      apiKey: key || "OFFLINE_DUMMY_KEY",
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// API endpoint for admin password verification
app.post("/api/admin/verify", (req, res) => {
  const { password } = req.body;
  const adminPassword = process.env.ADMIN_PASSWORD || "GeoAdmin2026!";
  if (password === adminPassword) {
    return res.json({ success: true });
  }
  return res.json({ success: false, error: "Onjuist wachtwoord!" });
});

// API endpoint for study advice and learning path prediction
app.post("/api/study-advice", async (req, res) => {
  const { stats, region, category } = req.body;

  // Compute a beautiful heuristic fallback in case offline or API key is missing
  const makeHeuristicAdvice = () => {
    const weaknesses = stats?.weaknesses || [];
    const accuracy = stats?.accuracy || 0;
    const streak = stats?.streak || 0;
    const totalAnswered = stats?.totalAnswered || 0;

    let adviceText = "Welkom bij GeoTrainer Pro! ";
    if (totalAnswered === 0) {
      adviceText += "Selecteer een lesmodule (bijvoorbeeld België Provincies) en start een quiz om jouw unieke leertraject op te bouwen.";
    } else if (accuracy < 50) {
      adviceText += `Jouw huidige scoreprecisie is ${accuracy}%. We raden aan om te beginnen met **Flashcards** om de verbindingen tussen landen, hoofdsteden en provincies eerst rustig in te studeren voordat je de tijduitdagingen opneemt.`;
    } else if (weaknesses.length > 0) {
      const topWeak = weaknesses[0];
      adviceText += `Je maakt momenteel de meeste fouten bij **${topWeak.name}**. Oefentechnisch advies: start een gerichte Multiple-Choice of Invul-oefening voor deze specifieke categorie om dit zwakke punt weg te werken!`;
    } else {
      adviceText += `Geweldig werk! Met een scoreprecisie van ${accuracy}% en een streak van ${streak} actieve leerdagen ben je uitstekend op weg. Probeer eens de **Blind Map** modus van de interactieve kaarten om jezelf nog dieper uit te dagen!`;
    }

    // Predict upcoming difficult targets
    const predictedDifficult: string[] = [];
    if (region === 'belgium') {
      predictedDifficult.push("Luxemburg (Aarlen - vaak verward met het land)", "Waals-Brabant (Waver - kleinste provincie)");
    } else if (region === 'europe') {
      predictedDifficult.push("Balkanstaten (Montenegro, Kosovo, Albanië)", "Dnjepr en Wolga rivieren");
    } else {
      predictedDifficult.push("Kunlun Shan gebergte", "Darling en Paraná rivieren");
    }

    return {
      advice: adviceText,
      predictedDifficult,
      focusExercise: accuracy < 70 ? 'flashcard' : 'map',
      isHeuristic: true
    };
  };

  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    return res.json(makeHeuristicAdvice());
  }

  try {
    const ai = getGeminiClient();
    const weaknessesList = (stats?.weaknesses || []).map((w: any) => `${w.name} (${w.region})`).join(", ");
    
    const prompt = `Je bent een vriendelijke, professionele aardrijkskundeleraar die studenten motiveert.
Analyseer de volgende prestatiegegevens en geef bruikbaar leertrajectadvies in het Nederlands.

Gegevens:
- Algemene Scoreprecisie: ${stats?.accuracy || 0}%
- Actieve Dagelijkse Streak: ${stats?.streak || 0} dagen
- Totaal Beantwoorde Vragen: ${stats?.totalAnswered || 0}
- Zwakke punten (frequent onjuist): [${weaknessesList}]
- Huidige module: Region: [${region || 'Geen'}], Category: [${category || 'Geen'}]

Reageer met een JSON-object met exact deze structuur:
{
  "advice": "Een motiverende en specifiek op de zwakke punten gerichte leertip in 2 of 3 zinnen.",
  "predictedDifficult": [
    "Naam van complex object 1 met verklaring waarom dit historisch/geografisch moeilijk is",
    "Naam van complex object 2 met een mnemotechnisch ezelsbruggetje"
  ],
  "focusExercise": "multiple-choice" of "fill-in" of "map" of "flashcard" (kies de meest geschikte herhalingsmethode gebaseerd op hun accurate niveau)
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const parsedResponse = JSON.parse(response.text || "{}");
    return res.json({
      advice: parsedResponse.advice || "Zet door en herhaal dagelijks!",
      predictedDifficult: parsedResponse.predictedDifficult || [],
      focusExercise: parsedResponse.focusExercise || "flashcard",
      isHeuristic: false
    });
  } catch (error) {
    console.error("Gemini advice API error:", error);
    return res.json(makeHeuristicAdvice());
  }
});

// Configure Vite or Static Serve
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
