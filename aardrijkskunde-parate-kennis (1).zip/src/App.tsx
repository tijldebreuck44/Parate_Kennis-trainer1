import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Region, QuizMode, QuestionType, Question } from './types/geography';
import { useQuizEngine, UserStats } from './hooks/useQuizEngine';
import MultipleChoice from './components/exercises/MultipleChoice';
import FillInBlank from './components/exercises/FillInBlank';
import FlagQuiz from './components/exercises/FlagQuiz';
import Flashcards from './components/exercises/Flashcards';
import Stats from './components/layout/Stats';
import DataValidator from './components/admin/DataValidator';
import DatasetAdmin from './components/admin/DatasetAdmin';
import GeoQuiz from './components/GeoQuiz';
import sound from './utils/audio';
import confetti from 'canvas-confetti';
import { getDutchCategoryLabel } from './utils/questionDescriptions';
import { 
  Compass, Award, Database, BarChart3, Settings, Play, RefreshCw, 
  ArrowLeft, Brain, Hourglass, ShieldAlert, Sparkles, Moon, Sun, 
  HelpCircle, CheckCircle2, ChevronRight, XCircle, Map, Lock, KeyRound,
  Volume2, VolumeX
} from 'lucide-react';

const formatStopwatch = (seconds: number) => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
};

interface AdminLoginFormProps {
  theme: 'dark' | 'light';
  onSubmit: (e: React.FormEvent) => void;
  password: string;
  setPassword: (val: string) => void;
  error: string | null;
  loading: boolean;
}

function AdminLoginForm({ theme, onSubmit, password, setPassword, error, loading }: AdminLoginFormProps) {
  return (
    <div className="max-w-md mx-auto my-12 animate-fade-in">
      <div className={`p-8 rounded-3xl border shadow-2xl ${
        theme === 'dark' ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-850'
      }`}>
        <div className="flex flex-col items-center text-center mb-6">
          <div className={`p-4 rounded-full mb-3 ${
            theme === 'dark' ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30' : 'bg-blue-50 text-blue-600 border border-blue-105/50'
          }`}>
            <Lock className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold tracking-tight">Beheerderspaneel Vergrendeld</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-xs">
            Voer het beheerderswachtwoord in om de datasets aan te passen of te controleren.
          </p>
        </div>

        <form onSubmit={onSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-mono font-bold uppercase text-slate-400 mb-2">
              Wachtwoord
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••••••"
              disabled={loading}
              className={`w-full px-4 py-3 rounded-xl border font-mono text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all ${
                theme === 'dark'
                  ? 'bg-slate-950 border-slate-800 text-white placeholder-slate-600'
                  : 'bg-slate-50 border-slate-200 text-slate-800 placeholder-slate-400'
              }`}
              required
            />
          </div>

          {error && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-400 text-xs font-medium flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-550 animate-pulse shrink-0"></span>
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-xl text-sm font-bold tracking-tight shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            {loading ? (
              <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
            ) : (
              <span>Ontgrendel Toegang</span>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}

export default function App() {
  // Global View Navigation Tabs
  const [activeTab, setActiveTab] = useState<'home' | 'stats' | 'advice' | 'debug' | 'admin'>('home');
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  // Study Config State
  const [activeRegion, setActiveRegion] = useState<Region>('belgium');
  const [activeCategory, setActiveCategory] = useState<QuestionType>('province');
  const [activeMode, setActiveCategoryMode] = useState<QuizMode>('multiple-choice');

  // Active quiz gameplay session variables
  const [isPlaying, setIsPlaying] = useState(false);
  const [quizTimer, setQuizTimer] = useState<number>(0);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [totalTimeSpent, setTotalTimeSpent] = useState<number>(0);
  const [elapsedTimePerQuestion, setElapsedTimePerQuestion] = useState<number>(0);
  const quizTimerRef = useRef<NodeJS.Timeout | null>(null);
  const questionStartTimeRef = useRef<number>(0);

  // Dynamic AI study advisor advice payload state
  const [aiLoading, setAiLoading] = useState(false);
  const [aiAdvice, setAiAdvice] = useState<{
    advice: string;
    predictedDifficult: string[];
    focusExercise: QuizMode;
  } | null>(null);

  // Initialize the specific quiz engine configurations
  const {
    currentQuestion,
    generateQuestion,
    submitAnswer,
    sessionScore,
    sessionTotal,
    userStats,
    resetSession,
    setSessionScore,
    sessionErrors
  } = useQuizEngine(activeRegion, activeCategory, activeMode, {
    subType: activeCategory === 'country' || activeCategory === 'province' ? 'capital' : 'name'
  });

  // Admin authentication states
  const [isAdmin, setIsAdmin] = useState(() => localStorage.getItem('geoAdminAuth') === 'true');
  const [adminPasswordInput, setAdminPasswordInput] = useState('');
  const [adminError, setAdminError] = useState<string | null>(null);
  const [adminLoading, setAdminLoading] = useState(false);

  // Sound effect state
  const [isSoundMuted, setIsSoundMuted] = useState(() => sound.getMuted());

  const toggleSound = () => {
    const nextMute = !isSoundMuted;
    sound.setMuted(nextMute);
    setIsSoundMuted(nextMute);
  };

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdminError(null);
    setAdminLoading(true);
    try {
      const res = await fetch('/api/admin/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: adminPasswordInput })
      });
      const data = await res.json();
      if (data.success) {
        setIsAdmin(true);
        localStorage.setItem('geoAdminAuth', 'true');
        setAdminPasswordInput('');
      } else {
        setAdminError(data.error || 'Onjuist wachtwoord!');
      }
    } catch (err) {
      setAdminError('Er is een fout opgetreden bij het verbinden met de server.');
    } finally {
      setAdminLoading(false);
    }
  };

  const handleAdminLogout = () => {
    setIsAdmin(false);
    localStorage.removeItem('geoAdminAuth');
  };

  // Manage light and dark global HTML class
  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'light') {
      root.classList.add('light');
      root.classList.remove('dark');
    } else {
      root.classList.add('dark');
      root.classList.remove('light');
    }
  }, [theme]);

  // Sync default category selections when shifting regions
  useEffect(() => {
    if (activeRegion === 'belgium') {
      setActiveCategory('province');
    } else if (activeRegion === 'europe') {
      setActiveCategory('country');
    } else {
      setActiveCategory('country');
    }
    
    // Flag recognition is only allowed for Europe
    if (activeRegion !== 'europe' && activeMode === 'flag') {
      setActiveCategoryMode('multiple-choice');
    }
  }, [activeRegion, activeMode]);

  const handleCategorySelect = (cat: QuestionType) => {
    setActiveCategory(cat);
    if (activeMode === 'flag' && activeRegion !== 'europe') {
      setActiveCategoryMode('multiple-choice');
    }
  };

  // Track gameplay stopwatch (count up)
  useEffect(() => {
    if (isPlaying) {
      setQuizTimer(0);
      setTotalTimeSpent(0);
      quizTimerRef.current = setInterval(() => {
        setQuizTimer(prev => prev + 1);
        setTotalTimeSpent(t => t + 1);
      }, 1000);
    }
    return () => {
      if (quizTimerRef.current) clearInterval(quizTimerRef.current);
    };
  }, [isPlaying]);

  const handleQuizTimeExpiry = () => {
    if (quizTimerRef.current) clearInterval(quizTimerRef.current);
    sound.playStreak();
    setQuizCompleted(true);
    
    // Confetti on outstanding score
    if (sessionScore > 0 && sessionScore === sessionTotal) {
      confetti({ particleCount: 150, spread: 80, origin: { y: 0.6 } });
    }
  };

  const startQuizSession = () => {
    if (quizTimerRef.current) clearInterval(quizTimerRef.current);
    resetSession();
    generateQuestion();
    setTotalTimeSpent(0);
    setQuizCompleted(false);
    setIsPlaying(true);
    questionStartTimeRef.current = Date.now();
  };

  const handleNextQuestion = () => {
    generateQuestion();
    questionStartTimeRef.current = Date.now();
  };

  const handleResultSubmit = (isCorrect: boolean, chosenVal: string) => {
    const elapsed = (Date.now() - questionStartTimeRef.current) / 1000;
    
    // Play synthesized custom tone live
    if (isCorrect) {
      sound.playCorrect();
    } else {
      sound.playWrong();
    }

    submitAnswer(isCorrect ? currentQuestion!.correctAnswer : chosenVal, elapsed);

    // Limit or single session end trigger checks
    if (activeMode === 'review-errors' && isCorrect && sessionErrors.length <= 1) {
      setTimeout(() => {
        setIsPlaying(false);
        setQuizCompleted(true);
        confetti({ particleCount: 150, spread: 80, origin: { y: 0.6 } });
      }, 1500);
    } else if (sessionTotal >= 14) {
      // Finished default pool size, trigger perfect confetti & wrap up
      handleQuizTimeExpiry();
    } else {
      // Trigger smooth automatic replacement transition
      setTimeout(() => {
        handleNextQuestion();
      }, 2300);
    }
  };

  const quitQuizSession = () => {
    if (quizTimerRef.current) clearInterval(quizTimerRef.current);
    setIsPlaying(false);
    setQuizCompleted(false);
    resetSession();
  };

  // API load handler for the AI Study advisor coaching recommendation
  const loadAIAdviceAndPath = async () => {
    setAiLoading(true);
    setAiAdvice(null);
    try {
      const response = await fetch('/api/study-advice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          stats: userStats,
          region: activeRegion,
          category: activeCategory
        })
      });
      const data = await response.json();
      setAiAdvice(data);
    } catch (e) {
      console.error("Failed to load Gemini advisor route", e);
    } finally {
      setAiLoading(false);
    }
  };

  // Launch AI advisor load on tab click
  useEffect(() => {
    if (activeTab === 'advice') {
      loadAIAdviceAndPath();
    }
  }, [activeTab]);

  const clearProgressAndStats = () => {
    if (confirm("Weet je zeker dat je alle behaalde scores, streaks en spaced repetition records permanent wilt wissen? Dit kan niet ongedaan worden gemaakt.")) {
      localStorage.removeItem('geo_trainer_stats');
      localStorage.removeItem('geo_trainer_progress');
      localStorage.removeItem('geo_trainer_custom_items');
      window.location.reload();
    }
  };

  return (
    <div className={`min-h-screen font-sans transition-all duration-350 p-2 sm:p-6 md:p-8 relative ${
      theme === 'dark' 
        ? 'bg-[#0f172a] text-slate-100 selection:bg-blue-500/20 selection:text-blue-300' 
        : 'bg-[#fafafc] text-slate-800 selection:bg-blue-600/10 selection:text-blue-700'
    }`}>
      {/* Background radial soft high-contrast ambient spot meshes */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden origin-top-left z-0 opacity-40">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-blue-600 blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-indigo-800 blur-[120px]" />
      </div>

      {/* Primary Container Box Layer */}
      <div className="max-w-6xl mx-auto relative z-10 space-y-6">
        {/* Navigation Core HUD bar */}
        <header className={`flex flex-col sm:flex-row justify-between items-center gap-4 p-5 rounded-3xl border shadow-xl ${
          theme === 'dark' 
            ? 'bg-white/5 border-white/10 backdrop-blur-xl text-white' 
            : 'bg-white/80 border-slate-200/70 backdrop-blur-xl'
        }`}>
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-tr from-blue-500 to-indigo-600 rounded-2xl shadow-lg shadow-blue-500/20 cursor-pointer animate-spin-slow" onClick={() => window.location.reload()}>
              <Compass className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-black bg-clip-text text-transparent bg-gradient-to-r from-white via-slate-200 to-slate-400">
                GeoTrainer Pro
              </h1>
              <span className="text-[10px] text-slate-400 font-mono font-bold tracking-widest uppercase">Parate Kennis platform</span>
            </div>
          </div>

          {/* Quick Stats, Theme and Tab items */}
          <div className="flex items-center gap-2 flex-wrap">
            <div className={`px-4 py-2 rounded-xl flex items-center gap-2 border font-semibold ${
              theme === 'dark' ? 'bg-white/5 border-white/10 text-amber-400 backdrop-blur-md' : 'bg-slate-100/80 border-slate-200 text-slate-700'
            }`}>
              <span>Streak:</span>
              <span className="font-extrabold flex items-center gap-1">
                {userStats.streak || 1} 🔥
              </span>
            </div>

            {/* Audio volume/silence handle trigger */}
            <button
              onClick={toggleSound}
              title={isSoundMuted ? "Geluidseffecten aanzetten" : "Geluidseffecten dempen"}
              className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-center ${
                theme === 'dark' 
                  ? 'bg-white/5 border-white/10 text-slate-300 hover:text-white hover:bg-white/10' 
                  : 'bg-white border-slate-200 text-slate-600 hover:text-black hover:bg-slate-100'
              }`}
            >
              {isSoundMuted ? (
                <VolumeX className="w-5 h-5 text-rose-500" />
              ) : (
                <Volume2 className="w-5 h-5 text-emerald-500" />
              )}
            </button>

            {/* Dark Light mode handle triggers */}
            <button
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                theme === 'dark' ? 'bg-white/5 border-white/10 text-slate-300 hover:text-white hover:bg-white/10' : 'bg-white border-slate-200 text-slate-600 hover:text-black hover:bg-slate-100'
              }`}
            >
              {theme === 'dark' ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5" />}
            </button>
          </div>
        </header>

        {/* Modular View Dashboard Tabs Navigation bar */}
        {!isPlaying && (
          <nav className={`flex sm:justify-start gap-1 p-2 rounded-2xl border overflow-x-auto ${
            theme === 'dark' ? 'bg-white/5 border-white/10 backdrop-blur-xl' : 'bg-white/80 border-slate-200/50 shadow-sm'
          }`}>
            {[
              { id: 'home', label: 'Dashboard', icon: Compass },
              { id: 'mapQuiz', label: 'Kaart Quiz', icon: Map },
              { id: 'stats', label: 'Statistieken', icon: BarChart3 },
              { id: 'advice', label: 'AI Studiekeuze', icon: Brain },
              { id: 'admin', label: 'Beheer Databank', icon: Settings },
              { id: 'debug', label: 'Debugger & Validator', icon: ShieldAlert }
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-2 px-4.5 py-3.5 rounded-xl text-sm font-bold tracking-tight transition-all duration-200 whitespace-nowrap cursor-pointer ${
                    isActive
                      ? 'bg-blue-600 border border-blue-400 text-white shadow-lg shadow-blue-500/25 scale-[1.03]'
                      : theme === 'dark'
                        ? 'text-slate-400 hover:bg-white/5 hover:text-slate-200 border border-transparent'
                        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 border border-transparent'
                  }`}
                >
                  <Icon className="w-4.5 h-4.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        )}

        {/* Gameplay Stage Frame Overlay */}
        {isPlaying ? (
          <div className={`p-4 sm:p-8 rounded-3xl border shadow-2xl relative overflow-hidden ${
            theme === 'dark' ? 'bg-white/5 border-white/10 backdrop-blur-2xl' : 'bg-white border-slate-200'
          }`}>
            {/* Countdown Clock HUD banner */}
            <div className={`flex justify-between items-center pb-4 border-b mb-6 ${
              theme === 'dark' ? 'border-white/10' : 'border-slate-200'
            }`}>
              <button
                onClick={quitQuizSession}
                className="flex items-center gap-1.5 text-slate-450 hover:text-rose-450 transition-all font-bold font-sans text-sm cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Stop Oefening</span>
              </button>

              <div className="flex items-center gap-4">
                <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border font-mono font-extrabold ${
                  theme === 'dark' ? 'bg-white/5 border-white/10 text-emerald-400' : 'bg-emerald-50 border-emerald-100 text-emerald-600'
                }`}>
                  <Hourglass className="w-4 h-4 shrink-0 animate-spin-slow" />
                  <span>{formatStopwatch(quizTimer)}</span>
                </div>
                
                <div className={`font-mono text-sm px-3 py-1.5 rounded-lg border font-bold ${
                  theme === 'dark' ? 'bg-white/5 border-white/10' : 'bg-slate-50 border-slate-200'
                }`}>
                  Juist: <span className="text-emerald-400 font-extrabold">{sessionScore}</span> / {sessionTotal}
                </div>
              </div>
            </div>

            {/* Main Interactive Stage Box */}
            {quizCompleted ? (
              <div className="text-center py-12 max-w-sm mx-auto">
                <div className="w-20 h-20 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center rounded-3xl mx-auto mb-6 text-4xl shadow-lg shadow-emerald-500/10">
                  🏆
                </div>
                <h3 className="text-3xl font-extrabold tracking-tight">Oefening Afgerond!</h3>
                <p className="text-slate-400 text-sm mt-2">Je hebt met succes de geplande sessie afgerond.</p>

                <div className={`grid grid-cols-3 gap-4 mt-6 p-5 rounded-2xl border border-dashed ${
                  theme === 'dark' ? 'bg-white/5 border-white/10' : 'bg-slate-50 border-slate-200'
                }`}>
                  <div>
                    <span className="text-slate-400 text-xs font-mono font-bold uppercase block">Juiste antwoorden</span>
                    <span className="text-2xl font-black text-emerald-400 mt-1">{sessionScore}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-xs font-mono font-bold uppercase block">Nauwkeurigheid</span>
                    <span className="text-2xl font-black text-blue-400 mt-1">
                      {sessionTotal > 0 ? Math.round((sessionScore / sessionTotal) * 100) : 0}%
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-xs font-mono font-bold uppercase block">Totale Tijd</span>
                    <span className="text-2xl font-black text-amber-400 mt-1">{formatStopwatch(quizTimer)}</span>
                  </div>
                </div>

                <div className="flex gap-4 mt-8">
                  <button
                    onClick={startQuizSession}
                    className="flex-1 py-3 px-4 bg-blue-600 hover:bg-blue-500 text-white rounded-xl border border-blue-400/30 font-bold transition-all shadow-lg shadow-blue-500/20 cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <RefreshCw className="w-4 h-4" />
                    <span>Nieuwe Start</span>
                  </button>
                  <button
                    onClick={quitQuizSession}
                    className="flex-1 py-3 px-4 bg-white/10 hover:bg-white/20 text-white rounded-xl border border-white/10 font-bold transition-all cursor-pointer"
                  >
                    Menu sluiten
                  </button>
                </div>
              </div>
            ) : currentQuestion ? (
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentQuestion.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.18 }}
                  className="py-6"
                >
                  {(activeMode === 'multiple-choice' || (activeMode === 'review-errors' && currentQuestion.type === 'multiple-choice')) && (
                    <MultipleChoice question={currentQuestion} onResult={handleResultSubmit} />
                  )}
                  {(activeMode === 'fill-in' || (activeMode === 'review-errors' && currentQuestion.type === 'fill-in')) && (
                    <FillInBlank question={currentQuestion} onResult={handleResultSubmit} />
                  )}
                  {(activeMode === 'flag' || (activeMode === 'review-errors' && currentQuestion.type === 'flag')) && (
                    <FlagQuiz question={currentQuestion} onResult={handleResultSubmit} />
                  )}
                  {(activeMode === 'flashcard' || (activeMode === 'review-errors' && currentQuestion.type === 'flashcard')) && (
                    <Flashcards 
                      items={[currentQuestion.geoItem]} 
                      categoryName={`${(currentQuestion.dataset || activeRegion).toUpperCase()} - ${getDutchCategoryLabel(currentQuestion.category || activeCategory).toUpperCase()}`}
                      onFinish={handleNextQuestion}
                    />
                  )}
                </motion.div>
              </AnimatePresence>
            ) : (
              <div className="text-center py-16 text-slate-500 font-semibold font-mono uppercase text-xs">
                Leermateriaal aan het laden...
              </div>
            )}
          </div>
        ) : (
          /* Normal Tab selections viewports */
          <div className="space-y-6">
            {/* View Tab Home (Main Selector Dashboard) */}
            {activeTab === 'home' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Parameter choices configurations card */}
                <div role="region" className={`lg:col-span-2 p-6 sm:p-8 rounded-3xl border shadow-2xl flex flex-col justify-between ${
                  theme === 'dark' ? 'bg-white/5 border-white/10 backdrop-blur-xl text-white' : 'bg-white border-slate-200 shadow-sm'
                }`}>
                  <div className="space-y-6">
                    <h3 className="text-xl font-bold font-sans tracking-tight">Stel je oefening in</h3>

                    {/* Module (Region) Selection */}
                    <div>
                      <span className="block text-xs font-mono font-bold uppercase text-slate-450 mb-2.5">Lesmodule</span>
                      <div className="grid grid-cols-3 gap-2">
                        {[
                          { id: 'belgium', label: 'België', desc: 'Provincies, steden, havens, gewesten', color: 'hover:border-yellow-500/30' },
                          { id: 'europe', label: 'Europa', desc: '41 landen, hoofdsteden, zeeën, gebergten', color: 'hover:border-blue-500/30' },
                          { id: 'world', label: 'Wereld', desc: 'Continenten, oceanen, referentielijnen, landen', color: 'hover:border-emerald-500/30' }
                        ].map((choice) => {
                          const isSelected = activeRegion === choice.id;
                          return (
                            <button
                              key={choice.id}
                              onClick={() => setActiveRegion(choice.id as Region)}
                              className={`p-4 rounded-2xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1.5 ${
                                isSelected
                                  ? 'bg-blue-600 border-blue-400 text-white scale-[1.02] font-black shadow-lg shadow-blue-500/25'
                                  : theme === 'dark'
                                    ? 'bg-white/5 border-white/10 text-slate-300 ' + choice.color
                                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100 ' + choice.color
                              }`}
                            >
                              <span className="text-base font-bold font-sans">{choice.label}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Category Selection */}
                    <div>
                      <span className="block text-xs font-mono font-bold uppercase text-slate-450 mb-2.5">Categorie</span>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        {activeRegion === 'belgium' && [
                          { id: 'province', label: 'Provincies' },
                          { id: 'river', label: 'Rivieren' },
                          { id: 'port', label: 'Havens' },
                          { id: 'highway', label: 'Autosnelwegen' }
                        ].map((cat) => (
                          <button
                            key={cat.id}
                            onClick={() => handleCategorySelect(cat.id as QuestionType)}
                            className={`py-3 px-4 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                              activeCategory === cat.id
                                ? 'bg-blue-600/20 border-blue-400 text-blue-300 shadow-sm shadow-blue-500/10'
                                : theme === 'dark'
                                  ? 'bg-white/5 border-white/10 text-slate-400 hover:text-white hover:bg-white/10'
                                  : 'bg-slate-50 border-slate-200 text-slate-605 hover:text-black hover:bg-slate-100'
                            }`}
                          >
                            {cat.label}
                          </button>
                        ))}

                        {activeRegion === 'europe' && [
                          { id: 'country', label: 'Land en Hoofdstad' },
                          { id: 'sea', label: 'Zeeën en Kanalen' },
                          { id: 'river', label: 'Mondingen & Rivieren' },
                          { id: 'mountain', label: 'Gebergten' }
                        ].map((cat) => (
                          <button
                            key={cat.id}
                            onClick={() => handleCategorySelect(cat.id as QuestionType)}
                            className={`py-3 px-4 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                              activeCategory === cat.id
                                ? 'bg-blue-600/20 border-blue-400 text-blue-300 shadow-sm shadow-blue-500/10'
                                : theme === 'dark'
                                  ? 'bg-white/5 border-white/10 text-slate-400 hover:text-white hover:bg-white/10'
                                  : 'bg-slate-50 border-slate-200 text-slate-605 hover:text-black hover:bg-slate-100'
                            }`}
                          >
                            {cat.label}
                          </button>
                        ))}

                        {activeRegion === 'world' && [
                          { id: 'continent', label: 'Werelddelen' },
                          { id: 'ocean', label: 'Oceanen' },
                          { id: 'country', label: 'Rijkslanden' },
                          { id: 'city', label: 'Wereldsteden' },
                          { id: 'line', label: 'Referentielijnen' },
                          { id: 'river', label: 'Wereldrivieren' },
                          { id: 'mountain', label: 'Gebergteketens' }
                        ].map((cat) => (
                          <button
                            key={cat.id}
                            onClick={() => handleCategorySelect(cat.id as QuestionType)}
                            className={`py-3 px-4 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                              activeCategory === cat.id
                                ? 'bg-blue-600/20 border-blue-400 text-blue-300 shadow-sm shadow-blue-500/10'
                                : theme === 'dark'
                                  ? 'bg-white/5 border-white/10 text-slate-400 hover:text-white hover:bg-white/10'
                                  : 'bg-slate-50 border-slate-200 text-slate-605 hover:text-black hover:bg-slate-100'
                            }`}
                          >
                            {cat.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Exercise Mode Selection */}
                    <div>
                      <span className="block text-xs font-mono font-bold uppercase text-slate-450 mb-2">Oefenvorm</span>
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
                        {[
                          { id: 'multiple-choice', label: 'Multiple Choice' },
                          { id: 'fill-in', label: 'Zelf Invullen' },
                          ...(activeRegion === 'europe' ? [{ id: 'flag', label: 'Vlaggen Herkennen' }] : []),
                          { id: 'flashcard', label: 'Flashcards' },
                          { id: 'review-errors', label: `Fouten Herhalen (${sessionErrors.length})` }
                        ].map((modeOpt) => (
                          <button
                            key={modeOpt.id}
                            onClick={() => {
                              setActiveCategoryMode(modeOpt.id as QuizMode);
                              if (modeOpt.id === 'flag') {
                                if (activeRegion === 'belgium') {
                                  setActiveCategory('province');
                                } else {
                                  setActiveCategory('country');
                                }
                              }
                            }}
                            className={`py-3 px-4 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                              activeMode === modeOpt.id
                                ? 'bg-blue-600/20 border-blue-400 text-blue-300 shadow-sm shadow-blue-500/10'
                                : theme === 'dark'
                                  ? 'bg-white/5 border-white/10 text-slate-400 hover:text-white hover:bg-white/10'
                                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-black'
                            }`}
                          >
                            {modeOpt.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Geen tijdsdruk optie meer, stopwatch wordt automatisch gestart */}
                  </div>

                  {/* Operational Launch triggers button */}
                  <button
                    onClick={startQuizSession}
                    disabled={activeMode === 'review-errors' && sessionErrors.length === 0}
                    className={`w-full py-4.5 text-white rounded-2xl font-black text-lg transition-all focus:outline-none focus:ring-4 focus:ring-blue-500/20 shadow-lg mt-8 flex items-center justify-center gap-2.5 cursor-pointer hover:scale-[1.01] ${
                      activeMode === 'review-errors' && sessionErrors.length === 0
                        ? 'bg-slate-700/50 text-slate-500 border border-slate-800/20 pointer-events-none cursor-not-allowed shadow-none'
                        : 'bg-blue-600 hover:bg-blue-500 shadow-blue-500/20'
                    }`}
                  >
                    <Play className="w-5 h-5 fill-white" />
                    <span>
                      {activeMode === 'review-errors'
                        ? sessionErrors.length === 0
                          ? 'Geen fouten te herhalen'
                          : `Fouten herhalen (${sessionErrors.length})`
                        : 'Start Training'}
                    </span>
                  </button>
                </div>

                {/* Micro educational statistics column widget */}
                <div role="region" className={`p-6 rounded-3xl border shadow-2xl flex flex-col justify-between ${
                  theme === 'dark' ? 'bg-white/5 border-white/10 backdrop-blur-xl text-white' : 'bg-white border-slate-200 shadow-sm'
                }`}>
                  <div className="space-y-4">
                    <h4 className="text-slate-405 text-xs font-mono font-bold uppercase tracking-wider">Mijn Uitdagingen</h4>
                    
                    <div className={`border border-dashed p-4 rounded-2xl flex items-center gap-3 ${
                      theme === 'dark' ? 'border-white/10 bg-white/5' : 'border-slate-200 bg-slate-50'
                    }`}>
                      <div className="text-3xl">🎯</div>
                      <div>
                        <h5 className={`font-extrabold text-sm ${theme === 'dark' ? 'text-slate-200' : 'text-slate-800'}`}>Perfecte Score</h5>
                        <p className="text-[11px] text-slate-400 mt-1">Beantwoord alle vragen foutloos in een willekeurige quiz.</p>
                      </div>
                    </div>

                    <div className={`border border-dashed p-4 rounded-2xl flex items-center gap-3 ${
                      theme === 'dark' ? 'border-white/10 bg-white/5' : 'border-slate-200 bg-slate-50'
                    }`}>
                      <div className="text-3xl">⏰</div>
                      <div>
                        <h5 className={`font-extrabold text-sm ${theme === 'dark' ? 'text-slate-200' : 'text-slate-800'}`}>Tijdsdruk</h5>
                        <p className="text-[11px] text-slate-400 mt-1">Beantwoord minimaal 15 vragen binnen de 60s Tijdslimiet.</p>
                      </div>
                    </div>

                    <div className={`border border-dashed p-4 rounded-2xl flex items-center gap-3 ${
                      theme === 'dark' ? 'border-white/10 bg-white/5' : 'border-slate-200 bg-slate-50'
                    }`}>
                      <div className="text-3xl">📚</div>
                      <div>
                        <h5 className={`font-extrabold text-sm ${theme === 'dark' ? 'text-slate-200' : 'text-slate-800'}`}>Prenten Atlas</h5>
                        <p className="text-[11px] text-slate-400 mt-1">Bestudeer de theorie via de **Flashcard** herhaler.</p>
                      </div>
                    </div>
                  </div>

                  {/* Micro list of top successes */}
                  <div className={`mt-8 border-t pt-4 flex gap-4 items-center justify-between ${
                    theme === 'dark' ? 'border-white/10' : 'border-slate-200'
                  }`}>
                    <div>
                      <span className="text-[10px] text-slate-450 font-mono font-bold uppercase">Nauwkeurigheid</span>
                      <p className={`text-xl font-black mt-0.5 ${theme === 'dark' ? 'text-white' : 'text-slate-800'}`}>{userStats.accuracy || 0}%</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-450 font-mono font-bold uppercase">Beantwoord</span>
                      <p className={`text-xl font-black mt-0.5 ${theme === 'dark' ? 'text-white' : 'text-slate-800'}`}>{userStats.totalAnswered || 0}</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-450 font-mono font-bold uppercase">Unlocked Badges</span>
                      <p className="text-xl font-black text-blue-450 mt-0.5">{userStats.achievements?.length || 0}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* View Tab Kaart Quiz */}
            {activeTab === 'mapQuiz' && (
              <GeoQuiz />
            )}

            {/* View Tab Stats */}
            {activeTab === 'stats' && (
              <Stats stats={userStats} onClearStats={clearProgressAndStats} />
            )}

            {/* View Tab AI advice */}
            {activeTab === 'advice' && (
              <div className="max-w-3xl mx-auto space-y-6">
                <div className={`rounded-3xl p-8 border shadow-2xl ${
                  theme === 'dark' ? 'bg-white/5 border-white/10 backdrop-blur-xl text-white' : 'bg-white border-slate-200 shadow-sm'
                }`}>
                  <div className={`flex items-center gap-4 mb-6 pb-6 border-b ${
                    theme === 'dark' ? 'border-white/10' : 'border-slate-200'
                  }`}>
                    <div className={`p-3 rounded-2xl ${
                      theme === 'dark' ? 'bg-blue-600/15 border border-blue-400/30 text-blue-400' : 'bg-blue-50 border border-blue-100 text-blue-600'
                    }`}>
                      <Brain className="w-8 h-8" />
                    </div>
                    <div>
                      <h2 className="text-2xl font-bold tracking-tight">AI-Studiemodus & Kennisadviseur</h2>
                      <p className="text-sm text-slate-400">Gepersonaliseerd Nederlands leeradvies op basis van jouw actieve fouten en prestaties.</p>
                    </div>
                  </div>

                  {aiLoading ? (
                    <div className="text-center py-16 space-y-4">
                      <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent animate-spin rounded-full mx-auto"></div>
                      <h4 className="text-slate-400 text-sm font-medium font-mono uppercase tracking-wider">Gemini Kennispad Berekenen...</h4>
                      <p className="text-xs text-slate-500">We analyseren je zwakke punten en foutenpatronen.</p>
                    </div>
                  ) : aiAdvice ? (
                    <div className="space-y-6 animate-fade-in">
                      {/* Personal Coach Prompt box */}
                      <div className={`p-6 rounded-2xl border ${
                        theme === 'dark' ? 'bg-white/5 border-white/10' : 'bg-slate-50 border-slate-200 text-slate-800'
                      }`}>
                        <h4 className="text-xs font-mono font-bold text-blue-400 uppercase tracking-widest mb-2">Persoonlijk Studieadvies:</h4>
                        <p className={`text-base leading-relaxed font-medium ${theme === 'dark' ? 'text-slate-200' : 'text-slate-700'}`}>
                          {aiAdvice.advice}
                        </p>
                      </div>

                      {/* Predicted Pitfalls alerts */}
                      <div>
                        <h4 className="text-xs font-mono font-bold text-slate-450 uppercase tracking-widest mb-3">Voorspelde Struikelblokken (Moeilijke onderwerpen):</h4>
                        <div className="space-y-2">
                          {aiAdvice.predictedDifficult?.map((diff, i) => (
                            <div key={i} className={`flex gap-3 items-start p-4 rounded-xl border ${
                              theme === 'dark' ? 'bg-white/5 border-white/10 text-slate-300' : 'bg-slate-50 border-slate-200 text-slate-705'
                            }`}>
                              <Sparkles className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                              <span className="text-sm font-medium">{diff}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Focus recommended exercises style warning */}
                      <div className={`flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 p-5 rounded-2xl mt-4 border ${
                        theme === 'dark' ? 'bg-blue-600/10 border-blue-500/20 text-white' : 'bg-blue-50 border-blue-105/55 text-slate-850'
                      }`}>
                        <div>
                          <h5 className="font-bold text-sm text-blue-400">Aanbevolen Werkvorm Focus:</h5>
                          <p className="text-xs text-slate-400 mt-1">Gemini raadt aan om je vaardigheden nu op te vijzelen via:</p>
                        </div>
                        <span className="bg-blue-600 text-white font-extrabold text-sm px-4 py-2 rounded-xl capitalize shadow-md">
                          {aiAdvice.focusExercise}
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-12 text-slate-500 font-medium text-sm">
                      Kon geen studieadvies genereren. Zorg ervoor dat je verbonden bent met het netwerk en probeer het opnieuw.
                    </div>
                  )}

                  <div className="flex justify-end gap-2 mt-8 shrink-0">
                    <button
                      onClick={loadAIAdviceAndPath}
                      disabled={aiLoading}
                      className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 border border-blue-400/30 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-md"
                    >
                      Ververs Advies
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* View Tab Beheer (Dataset Admin) */}
            {activeTab === 'admin' && (
              !isAdmin ? (
                <AdminLoginForm
                  theme={theme}
                  onSubmit={handleAdminLogin}
                  password={adminPasswordInput}
                  setPassword={setAdminPasswordInput}
                  error={adminError}
                  loading={adminLoading}
                />
              ) : (
                <div className="space-y-4 animate-fade-in">
                  <div className={`flex justify-between items-center p-4 rounded-2xl border ${
                    theme === 'dark' ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
                  }`}>
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                      <span className={`text-xs font-bold font-mono uppercase tracking-wider ${theme === 'dark' ? 'text-emerald-400' : 'text-emerald-600'}`}>
                        Beheerder Geautoriseerd
                      </span>
                    </div>
                    <button
                      onClick={handleAdminLogout}
                      className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-md flex items-center gap-1.5"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>Log uit</span>
                    </button>
                  </div>
                  <DatasetAdmin />
                </div>
              )
            )}

            {/* View Tab Database Audit CLI */}
            {activeTab === 'debug' && (
              !isAdmin ? (
                <AdminLoginForm
                  theme={theme}
                  onSubmit={handleAdminLogin}
                  password={adminPasswordInput}
                  setPassword={setAdminPasswordInput}
                  error={adminError}
                  loading={adminLoading}
                />
              ) : (
                <div className="space-y-4 animate-fade-in">
                  <div className={`flex justify-between items-center p-4 rounded-2xl border ${
                    theme === 'dark' ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
                  }`}>
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                      <span className={`text-xs font-bold font-mono uppercase tracking-wider ${theme === 'dark' ? 'text-emerald-400' : 'text-emerald-600'}`}>
                        Beheerder Geautoriseerd
                      </span>
                    </div>
                    <button
                      onClick={handleAdminLogout}
                      className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-md flex items-center gap-1.5"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>Log uit</span>
                    </button>
                  </div>
                  <DataValidator />
                </div>
              )
            )}
          </div>
        )}
      </div>

      {/* Styled Footer signature block */}
      <footer className="max-w-6xl mx-auto mt-16 pt-6 border-t border-slate-900/35 text-center text-[10px] text-slate-600 font-mono tracking-widest uppercase">
        <span>© 2026 GEOTRAINER PRO • 100% DATABANK GESTUURD • OFFLINE EN CHROMBOOK GEREED</span>
      </footer>
    </div>
  );
}
