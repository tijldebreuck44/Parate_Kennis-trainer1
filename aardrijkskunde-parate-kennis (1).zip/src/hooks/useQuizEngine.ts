import { useState, useCallback, useEffect } from 'react';
import { Region, QuizMode, QuestionType, GeoItem, Question } from '../types/geography';
import belgiumData from '../data/belgium.json';
import europeData from '../data/europe.json';
import worldData from '../data/world.json';
import { validateAnswer } from '../utils/normalization';
import { getClueForGeoItem } from '../utils/questionDescriptions';

// Spaced repetition interval calculator (in days)
export const calculateNextReview = (consecutiveCorrect: number): number => {
  const intervals = [0, 1, 3, 7, 14, 30]; // 0 correct -> 0d, 1 -> 1d, 2 -> 3d, 3 -> 7d...
  return intervals[Math.min(consecutiveCorrect, intervals.length - 1)];
};

export interface QuizProgress {
  consecutiveCorrect: number;
  attempts: number;
  correct: number;
  nextReviewDate: number;
  wrongCount: number;
}

export interface UserStats {
  accuracy: number; // overall percentage
  streak: number; // active day count
  maxStreak: number;
  totalCorrect: number;
  totalAnswered: number;
  avgTime: number; // in seconds
  weaknesses: { itemId: string; name: string; region: Region; errorCount: number }[];
  achievements: string[]; // achievement keys
  lastActive: string; // ISO date string
}

export const useQuizEngine = (
  region: Region,
  category: QuestionType,
  mode: QuizMode,
  optionsConfig?: { subType?: 'capital' | 'name' | 'flag' }
) => {
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [history, setHistory] = useState<string[]>([]);
  const [sessionScore, setSessionScore] = useState(0);
  const [sessionTotal, setSessionTotal] = useState(0);
  const [sessionErrors, setSessionErrors] = useState<Question[]>([]);
  const [stats, setStats] = useState<UserStats>({
    accuracy: 0,
    streak: 0,
    maxStreak: 0,
    totalCorrect: 0,
    totalAnswered: 0,
    avgTime: 0,
    weaknesses: [],
    achievements: [],
    lastActive: new Date().toISOString().split('T')[0]
  });

  // Load stats from localstorage on mount
  useEffect(() => {
    const savedStats = localStorage.getItem('geo_trainer_stats');
    if (savedStats) {
      try {
        const parsed = JSON.parse(savedStats);
        // Verify last active to calculate streak
        const today = new Date().toISOString().split('T')[0];
        const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
        
        let activeStreak = parsed.streak || 0;
        if (parsed.lastActive === yesterday) {
          // Keep streak going! Checked in yesterday
        } else if (parsed.lastActive !== today) {
          // Missed a day, reset streak
          activeStreak = 1; // start new streak today
        }
        
        setStats({
          ...parsed,
          streak: activeStreak,
          lastActive: today
        });
      } catch (e) {
        console.error('Error loading stats', e);
      }
    } else {
      // First time save
      const today = new Date().toISOString().split('T')[0];
      const initial = {
        accuracy: 0,
        streak: 1,
        maxStreak: 1,
        totalCorrect: 0,
        totalAnswered: 0,
        avgTime: 0,
        weaknesses: [],
        achievements: [],
        lastActive: today
      };
      localStorage.setItem('geo_trainer_stats', JSON.stringify(initial));
      setStats(initial);
    }
  }, []);

  // Helper to get items based on region & category
  const getItemsForQuiz = useCallback((): GeoItem[] => {
    let source: any = [];
    if (region === 'belgium') {
      source = belgiumData;
    } else if (region === 'europe') {
      source = europeData;
    } else if (region === 'world') {
      source = worldData;
    }

    if (!source) return [];

    let items: GeoItem[] = [];
    switch (category) {
      case 'province':
        items = source.provinces || source.regions || [];
        break;
      case 'river':
        items = source.rivers || [];
        break;
      case 'mountain':
        items = source.mountains || source.gebergten || source.gebergten_plateaus || [];
        break;
      case 'sea':
        items = source.seas || source.zeeen_engtes || source.zeeen || [];
        break;
      case 'highway':
        items = source.highways || [];
        break;
      case 'port':
        items = source.ports || [];
        break;
      case 'country':
        items = source.countries || source.landen || [];
        break;
      case 'city':
        items = source.steden || [];
        break;
      case 'continent':
        items = source.continents || [];
        break;
      case 'ocean':
        items = source.oceans || [];
        break;
      case 'line':
        items = source.referenceLines || [];
        break;
      default:
        items = [];
    }
    
    // Normalize properties (id, name, capital etc)
    const baseItems = items.map((it: any) => ({
      id: it.id || `item-${(it.naam || it.name || '').toLowerCase().replace(/[^a-z0-9]/g, '-')}`,
      name: it.naam || it.name,
      capital: it.hoofdstad || it.capital || null,
      type: it.type || it.category || category,
      category: category,
      coordinates: it.coordinates || null,
      coordinatesList: it.coordinatesList || null,
      polygon: it.polygon || null,
      polygons: it.polygons || null,
      alternatives: it.alternatives || it.alternatief ? [it.alternatief || '', ...(it.alternatives || [])].filter(Boolean) : []
    }));

    // Merge custom added items from admin panel if they match current filters
    const customSaved = localStorage.getItem('geo_trainer_custom_items');
    if (customSaved) {
      try {
        const parsedCustom = JSON.parse(customSaved);
        const matchingCustom = parsedCustom
          .filter((it: any) => it.region === region && it.category === category)
          .map((it: any) => ({
            id: it.id,
            name: it.name,
            capital: it.capital || null,
            type: it.category,
            category: it.category,
            coordinates: null,
            coordinatesList: null,
            polygon: null,
            polygons: null,
            alternatives: []
          }));
        return [...matchingCustom, ...baseItems];
      } catch (e) {
        console.error(e);
      }
    }

    return baseItems;
  }, [region, category]);

  // Generate question
  const generateQuestion = useCallback(() => {
    if (mode === 'review-errors') {
      if (sessionErrors.length === 0) {
        setCurrentQuestion(null);
        return;
      }
      
      const eligibleErrors = sessionErrors.filter(q => !history.slice(-Math.min(sessionErrors.length - 1, 3)).includes(q.targetId));
      const pool = eligibleErrors.length > 0 ? eligibleErrors : sessionErrors;
      const selectedQuestion = pool[Math.floor(Math.random() * pool.length)];

      setCurrentQuestion({
        ...selectedQuestion,
        id: Math.random().toString(),
      });
      setHistory(prev => [...prev.slice(-30), selectedQuestion.targetId]);
      return;
    }

    const items = getItemsForQuiz();
    if (items.length === 0) {
      setCurrentQuestion(null);
      return;
    }

    // Determine target item using history and spaced repetition weight
    const srsDataRaw = localStorage.getItem('geo_trainer_progress') || '{}';
    const srsData: Record<string, QuizProgress> = JSON.parse(srsDataRaw);

    // Filter repeat candidates
    let candidates = [...items];
    const nonRepeated = items.filter(it => !history.slice(-Math.min(items.length - 1, 6)).includes(it.id));
    if (nonRepeated.length > 0) {
      candidates = nonRepeated;
    }

    // Weighted selection: items due for spaced repetition review or with high error counts get higher weight
    candidates.sort((a, b) => {
      const progressA = srsData[a.id] || { nextReviewDate: 0, wrongCount: 0 };
      const progressB = srsData[b.id] || { nextReviewDate: 0, wrongCount: 0 };
      
      const dueA = progressA.nextReviewDate <= Date.now() ? 10 : 1;
      const dueB = progressB.nextReviewDate <= Date.now() ? 10 : 1;
      
      const scoreA = dueA * (1 + (progressA.wrongCount || 0));
      const scoreB = dueB * (1 + (progressB.wrongCount || 0));
      
      return scoreB - scoreA; // highest score first
    });

    // Pick from the top candidates to keep randomness but prioritize weaker / due items
    const poolSize = Math.min(candidates.length, 3);
    const targetItem = candidates[Math.floor(Math.random() * poolSize)];

    let text = '';
    let correctAnswer = '';
    let options: string[] = [];
    const questionSubType = optionsConfig?.subType || 'name';

    if (mode === 'multiple-choice') {
      if (category === 'country' && questionSubType === 'capital') {
        text = `Wat is de hoofdstad van ${targetItem.name}?`;
        correctAnswer = targetItem.capital || 'Geen';
        // Distractors exclusively from other capitals in the same dataset
        const otherCapitals = items
          .filter(it => it.id !== targetItem.id && it.capital)
          .map(it => it.capital as string);
        const distractors = otherCapitals
          .sort(() => 0.5 - Math.random())
          .slice(0, 3);
        options = [correctAnswer, ...distractors].sort(() => 0.5 - Math.random());
      } else if (category === 'country' && questionSubType === 'name') {
        text = `Welk land hoort bij de hoofdstad ${targetItem.capital}?`;
        correctAnswer = targetItem.name;
        const otherNames = items
          .filter(it => it.id !== targetItem.id)
          .map(it => it.name);
        const distractors = otherNames
          .sort(() => 0.5 - Math.random())
          .slice(0, 3);
        options = [correctAnswer, ...distractors].sort(() => 0.5 - Math.random());
      } else if (category === 'province' && questionSubType === 'capital') {
        text = `Wat is de provinciehoofdstad van ${targetItem.name}?`;
        correctAnswer = targetItem.capital || 'Geen';
        const otherCapitals = items
          .filter(it => it.id !== targetItem.id && it.capital)
          .map(it => it.capital as string);
        const distractors = otherCapitals
          .sort(() => 0.5 - Math.random())
          .slice(0, 3);
        options = [correctAnswer, ...distractors].sort(() => 0.5 - Math.random());
      } else {
        // General text MCS Quiz - using descriptive clues
        text = getClueForGeoItem(targetItem.id, targetItem.name, category);
        correctAnswer = targetItem.name;
        const otherItems = items.filter(it => it.id !== targetItem.id).map(it => it.name);
        const distractors = otherItems.sort(() => 0.5 - Math.random()).slice(0, 3);
        options = [correctAnswer, ...distractors].sort(() => 0.5 - Math.random());
      }
    } else if (mode === 'fill-in') {
      if (category === 'country' && questionSubType === 'capital') {
        text = `Wat is de hoofdstad van ${targetItem.name}?`;
        correctAnswer = targetItem.capital || '';
      } else if (category === 'country' && questionSubType === 'name') {
        text = `Welk land heeft ${targetItem.capital} als hoofdstad?`;
        correctAnswer = targetItem.name;
      } else if (category === 'province' && questionSubType === 'capital') {
        text = `Wat is de hoofdstad van de provincie ${targetItem.name}?`;
        correctAnswer = targetItem.capital || '';
      } else {
        // Use custom descriptive clues in Dutch
        text = getClueForGeoItem(targetItem.id, targetItem.name, category);
        correctAnswer = targetItem.name;
      }
    } else if (mode === 'flag') {
      text = category === 'province' ? `Bij welke provincie hoort deze vlag?` : `Bij welk land hoort deze vlag?`;
      correctAnswer = targetItem.name;
      const otherNames = items
        .filter(it => it.id !== targetItem.id)
        .map(it => it.name);
      const distractors = otherNames
        .sort(() => 0.5 - Math.random())
        .slice(0, 3);
      options = [correctAnswer, ...distractors].sort(() => 0.5 - Math.random());
    } else if (mode === 'flashcard') {
      if (category === 'country') {
        text = `Wat is de hoofdstad van ${targetItem.name}?`;
        correctAnswer = targetItem.capital || 'Geen';
      } else if (category === 'province') {
        text = `Wat is de hoofstad van de provincie ${targetItem.name}?`;
        correctAnswer = targetItem.capital || 'Geen';
      } else {
        text = getClueForGeoItem(targetItem.id, targetItem.name, category);
        correctAnswer = targetItem.name;
      }
    }

    // Clean duplicate options (in case list was short or had matching items)
    options = Array.from(new Set(options));
    // Fallback if not enough options
    if (mode === 'multiple-choice' && options.length < 4) {
      // populate with placeholders or other items
      const filler = ["Antwerpen", "Brussel", "Parijs", "Londen", "Berlijn", "Madrid", "Rome"];
      for (const text of filler) {
        if (options.length < 4 && text !== correctAnswer && !options.includes(text)) {
          options.push(text);
        }
      }
    }

    setCurrentQuestion({
      id: Math.random().toString(),
      type: mode,
      category,
      text,
      correctAnswer,
      options,
      targetId: targetItem.id,
      dataset: region,
      geoItem: targetItem
    });
    setHistory(prev => [...prev.slice(-30), targetItem.id]);
  }, [region, category, mode, optionsConfig, history, getItemsForQuiz, sessionErrors]);

  // Record results and compute stats and achievements
  const submitAnswer = useCallback((answer: string, elapsedSeconds: number) => {
    if (!currentQuestion) return false;

    let isCorrect = false;
    const targetItem = currentQuestion.geoItem;

    const actualType = currentQuestion.type;
    if (actualType === 'multiple-choice' || actualType === 'flag') {
      isCorrect = answer === currentQuestion.correctAnswer;
    } else {
      // fill-in or flashcard
      isCorrect = validateAnswer(answer, currentQuestion.correctAnswer, targetItem.alternatives);
    }

    setSessionTotal(t => t + 1);
    if (isCorrect) {
      setSessionScore(s => s + 1);
      setSessionErrors(prev => prev.filter(q => q.targetId !== targetItem.id));
    } else {
      setSessionErrors(prev => {
        if (prev.some(q => q.targetId === targetItem.id)) return prev;
        return [...prev, currentQuestion];
      });
    }

    // 1. Spaced Repetition persistence Update
    const srsRaw = localStorage.getItem('geo_trainer_progress') || '{}';
    const srs: Record<string, QuizProgress> = JSON.parse(srsRaw);
    
    if (!srs[targetItem.id]) {
      srs[targetItem.id] = {
        consecutiveCorrect: 0,
        attempts: 0,
        correct: 0,
        nextReviewDate: 0,
        wrongCount: 0
      };
    }

    const itemProgress = srs[targetItem.id];
    itemProgress.attempts += 1;
    if (isCorrect) {
      itemProgress.correct += 1;
      itemProgress.consecutiveCorrect += 1;
    } else {
      itemProgress.consecutiveCorrect = 0;
      itemProgress.wrongCount += 1;
    }
    
    // Set next review interval
    const days = calculateNextReview(itemProgress.consecutiveCorrect);
    itemProgress.nextReviewDate = Date.now() + (days * 24 * 60 * 60 * 1000);
    srs[targetItem.id] = itemProgress;
    localStorage.setItem('geo_trainer_progress', JSON.stringify(srs));

    // 2. Weakness tracking
    const updatedWeaknesses = [...(stats.weaknesses || [])];
    const weaknessIndex = updatedWeaknesses.findIndex(w => w.itemId === targetItem.id);
    if (!isCorrect) {
      if (weaknessIndex >= 0) {
        updatedWeaknesses[weaknessIndex].errorCount += 1;
      } else {
        updatedWeaknesses.push({
          itemId: targetItem.id,
          name: targetItem.name,
          region,
          errorCount: 1
        });
      }
    } else {
      // If they got it right, reduce weakness error count slightly
      if (weaknessIndex >= 0) {
        updatedWeaknesses[weaknessIndex].errorCount = Math.max(0, updatedWeaknesses[weaknessIndex].errorCount - 1);
        if (updatedWeaknesses[weaknessIndex].errorCount === 0) {
          updatedWeaknesses.splice(weaknessIndex, 1);
        }
      }
    }
    // Sort weaknesses to keep worst first
    updatedWeaknesses.sort((a, b) => b.errorCount - a.errorCount);

    // 3. Overall Stats Calculation
    const totalCorrect = stats.totalCorrect + (isCorrect ? 1 : 0);
    const totalAnswered = stats.totalAnswered + 1;
    const accuracy = Math.round((totalCorrect / totalAnswered) * 100);
    
    // Avg time computation
    const totalOldTime = stats.avgTime * stats.totalAnswered;
    const newAvgTime = Number(((totalOldTime + elapsedSeconds) / totalAnswered).toFixed(1));

    // Achievements computation (Minimum 50 achievements listed!)
    const activeAchievements = [...(stats.achievements || [])];
    
    const awardUnique = (key: string) => {
      if (!activeAchievements.includes(key)) {
        activeAchievements.push(key);
      }
    };

    // Calculate dynamic milestone achievements
    if (totalAnswered >= 1) awardUnique('first_steps');
    if (totalAnswered >= 10) awardUnique('answered_10');
    if (totalAnswered >= 50) awardUnique('answered_50');
    if (totalAnswered >= 100) awardUnique('answered_100');
    if (totalAnswered >= 500) awardUnique('answered_500');
    if (totalAnswered >= 1000) awardUnique('answered_1000');

    if (totalCorrect >= 5) awardUnique('correct_5');
    if (totalCorrect >= 25) awardUnique('correct_25');
    if (totalCorrect >= 100) awardUnique('correct_100');
    if (totalCorrect >= 500) awardUnique('correct_500');

    // Streaks
    if (stats.streak >= 3) awardUnique('streak_3');
    if (stats.streak >= 7) awardUnique('streak_7');
    if (stats.streak >= 14) awardUnique('streak_14');
    if (stats.streak >= 30) awardUnique('streak_30');

    // Perfect round markers
    if (isCorrect && stats.streak > 5) awardUnique('accuracy_warrior');

    // Specific regions
    if (region === 'belgium' && isCorrect) awardUnique('belgium_explorer');
    if (region === 'europe' && isCorrect) awardUnique('europe_explorer');
    if (region === 'world' && isCorrect) awardUnique('world_explorer');

    // specific categories
    if (category === 'province' && isCorrect) awardUnique('province_specialist');
    if (category === 'river' && isCorrect) awardUnique('river_navigator');
    if (category === 'city' && isCorrect) awardUnique('urban_planner');
    if (category === 'country' && isCorrect) awardUnique('border_guard');
    if (category === 'sea' && isCorrect) awardUnique('captain');
    if (category === 'line' && isCorrect) awardUnique('equator_walker');

    // Accuracy milestones
    if (accuracy >= 80 && totalAnswered >= 50) awardUnique('smart_cookie');
    if (accuracy >= 95 && totalAnswered >= 100) awardUnique('geography_guru');

    const nextStats: UserStats = {
      ...stats,
      totalCorrect,
      totalAnswered,
      accuracy,
      avgTime: newAvgTime,
      weaknesses: updatedWeaknesses.slice(0, 15), // keep worst 15 weaknesses
      achievements: activeAchievements,
      lastActive: new Date().toISOString().split('T')[0]
    };

    setStats(nextStats);
    localStorage.setItem('geo_trainer_stats', JSON.stringify(nextStats));

    return isCorrect;
  }, [currentQuestion, stats, region, category, mode]);

  // Reset session counters
  const resetSession = useCallback(() => {
    setSessionScore(0);
    setSessionTotal(0);
    setSessionErrors([]);
  }, []);

  return {
    currentQuestion,
    generateQuestion,
    submitAnswer,
    sessionScore,
    sessionTotal,
    userStats: stats,
    resetSession,
    setSessionScore,
    sessionErrors
  };
};
