import React, { useEffect, useState, useRef } from 'react';
import * as d3 from 'd3';
import * as topojson from 'topojson-client';
import { worldCapitals, worldRivers, worldMountains, GeoFeature } from '../data/geoData';
import { Sparkles, Eye, Settings, Compass, Layers } from 'lucide-react';

interface WorldMapProps {
  activeQuestion?: {
    id: string;
    targetId: string;
    correctAnswer: string;
    geoItem?: any;
    category?: string;
  } | null;
  onResult?: (isCorrect: boolean, chosenVal: string) => void;
  interactiveMode?: boolean; // If true, acts as a quiz. If false, acts as study reference.
}

// Map numeric IDs from world-atlas to our world.json's IDs
const countryIdMap: Record<number, string> = {
  124: "wd-l-can", // Canada
  840: "wd-l-usa", // USA
  484: "wd-l-mex", // Mexico
  192: "wd-l-cub", // Cuba
  76:  "wd-l-bra", // Brazil
  862: "wd-l-ven", // Venezuela
  170: "wd-l-col", // Colombia
  604: "wd-l-per", // Peru
  152: "wd-l-chi", // Chile
  32:  "wd-l-arg", // Argentina
  818: "wd-l-egy", // Egypt
  12:  "wd-l-alg", // Algeria
  434: "wd-l-lby", // Libya
  504: "wd-l-mar", // Morocco
  788: "wd-l-tun", // Tunisia
  706: "wd-l-som", // Somalia
  231: "wd-l-eth", // Ethiopia
  736: "wd-l-sud", // Sudan
  404: "wd-l-ken", // Kenya
  646: "wd-l-rwa", // Rwanda
  108: "wd-l-bur", // Burundi
  466: "wd-l-mli", // Mali
  566: "wd-l-nga", // Nigeria
  384: "wd-l-civ", // Ivory Coast
  686: "wd-l-sen", // Senegal
  180: "wd-l-cod", // DR Congo
  710: "wd-l-zaf", // South Africa
  643: "wd-l-rus", // Russia
  804: "wd-l-ukr", // Ukraine
  586: "wd-l-pak", // Pakistan
  4:   "wd-l-afg", // Afghanistan
  760: "wd-l-syr", // Syria
  376: "wd-l-isr", // Israel
  360: "wd-l-idn", // Indonesia
  608: "wd-l-phl", // Philippines
  764: "wd-l-tha", // Thailand
  422: "wd-l-lbn", // Lebanon
  400: "wd-l-jor", // Jordan
  682: "wd-l-sau", // Saudi Arabia
  356: "wd-l-ind", // India
  156: "wd-l-chn", // China
  392: "wd-l-jpn", // Japan
  702: "wd-l-sgp", // Singapore
  36:  "wd-l-aus-country", // Australia
  554: "wd-l-nzl"  // New Zealand
};

export default function WorldMap({ activeQuestion, onResult, interactiveMode = true }: WorldMapProps) {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [countriesGeo, setCountriesGeo] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const [clickedItem, setClickedItem] = useState<string | null>(null);
  const [isCorrectState, setIsCorrectState] = useState<boolean | null>(null);

  // Active layers switches
  const [showCountries, setShowCountries] = useState(true);
  const [showCapitals, setShowCapitals] = useState(true);
  const [showRivers, setShowRivers] = useState(true);
  const [showMountains, setShowMountains] = useState(true);

  // Fetch geographic boundaries
  useEffect(() => {
    fetch('https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json')
      .then(res => res.json())
      .then(data => {
        const countriesArr = topojson.feature(data, data.objects.countries) as any;
        setCountriesGeo(countriesArr.features || []);
        setLoading(false);
      })
      .catch(err => {
        console.error("Error loading world atlas borders", err);
        setLoading(false);
      });
  }, []);

  // Map settings and sizes
  const width = 800;
  const height = 460;

  // Projection setup (Equirectangular fits the entire world in a standard widescreen aspect ratio)
  const projection = d3.geoEquirectangular()
    .scale(125)
    .translate([width / 2, height / 2 + 35]);

  const pathGenerator = d3.geoPath().projection(projection);

  // Clear states when target changes
  useEffect(() => {
    setClickedItem(null);
    setIsCorrectState(null);
  }, [activeQuestion]);

  const handleEntityClick = (itemId: string, itemName: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!interactiveMode || clickedItem) return;

    setClickedItem(itemId);

    if (activeQuestion) {
      // Validate correct answers
      const isCorrect = itemId === activeQuestion.targetId || 
                        itemName.toLowerCase() === activeQuestion.correctAnswer.toLowerCase();
      setIsCorrectState(isCorrect);

      if (onResult) {
        onResult(isCorrect, itemName);
      }
    }
  };

  return (
    <div className="space-y-4">
      {/* Map Control Layer Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-md">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-blue-400" />
          <span className="text-xs font-mono font-bold uppercase text-slate-400">Zichtbare Lagen:</span>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button 
            onClick={() => setShowCountries(p => !p)}
            className={`px-3 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
              showCountries ? 'bg-blue-600/20 border-blue-400 text-blue-300' : 'bg-transparent border-white/5 text-slate-500 hover:text-slate-300'
            }`}
          >
            🌍 Landen
          </button>
          <button 
            onClick={() => setShowCapitals(p => !p)}
            className={`px-3 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
              showCapitals ? 'bg-amber-600/20 border-amber-400 text-amber-300' : 'bg-transparent border-white/5 text-slate-500 hover:text-slate-300'
            }`}
          >
            🏛️ Hoofdsteden
          </button>
          <button 
            onClick={() => setShowRivers(p => !p)}
            className={`px-3 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
              showRivers ? 'bg-sky-600/20 border-sky-400 text-sky-300' : 'bg-transparent border-white/5 text-slate-500 hover:text-slate-300'
            }`}
          >
            🌊 Rivieren
          </button>
          <button 
            onClick={() => setShowMountains(p => !p)}
            className={`px-3 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
              showMountains ? 'bg-emerald-600/20 border-emerald-400 text-emerald-300' : 'bg-transparent border-white/5 text-slate-500 hover:text-slate-300'
            }`}
          >
            ⛰️ Gebergten
          </button>
        </div>
      </div>

      {/* Main Map SVG Area */}
      <div className="relative border border-white/10 rounded-3xl overflow-hidden bg-slate-950/80 shadow-2xl">
        {loading && (
          <div className="absolute inset-0 bg-slate-950/90 flex flex-col items-center justify-center space-y-3 z-30">
            <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-xs font-mono text-slate-400">Cartografie laden...</p>
          </div>
        )}

        {/* HUD Game Instruction */}
        {interactiveMode && activeQuestion && (
          <div className="absolute top-4 left-4 z-20 px-4 py-2 bg-slate-900/90 border border-white/10 rounded-xl backdrop-blur-md shadow-lg">
            <span className="text-[10px] font-mono font-bold uppercase text-blue-400 block tracking-widest">KARTOGRAFISCHE VRAAG:</span>
            <span className="text-base font-extrabold tracking-tight text-white block mt-0.5">
              {activeQuestion.geoItem?.capital && activeQuestion.category === 'capital'
                ? `Waar ligt de hoofdstad: ${activeQuestion.correctAnswer}?`
                : `Waar ligt het geografische object: ${activeQuestion.geoItem?.name || activeQuestion.correctAnswer}?`
              }
            </span>
          </div>
        )}

        <svg 
          ref={svgRef}
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto max-h-[500px] select-none text-slate-100"
          style={{ cursor: interactiveMode ? 'crosshair' : 'grab' }}
        >
          {/* Blue background representing ocean */}
          <rect width={width} height={height} fill="#0d1b2a55" />

          {/* Render Countries Layer */}
          {showCountries && (
            <g id="countries-layer">
              {countriesGeo.map((feature, i) => {
                const numericId = Number(feature.id);
                const mappedId = countryIdMap[numericId] || `country-${numericId}`;
                const countryName = feature.properties.name || "Land";

                // Styling decision
                let fill = '#1e293b'; // off-slate
                let stroke = '#334155'; // outline slate
                
                const isHovered = hoveredItem === mappedId;
                const isClicked = clickedItem === mappedId;

                if (isHovered) {
                  fill = '#2563eb'; // blue
                }

                if (isClicked) {
                  fill = isCorrectState ? '#10b981' : '#f43f5e'; // green or red
                }

                return (
                  <path
                    key={`country-${i}`}
                    d={pathGenerator(feature) || ''}
                    fill={fill}
                    stroke={stroke}
                    strokeWidth="0.5"
                    className={`transition-colors duration-150 cursor-pointer ${
                      isClicked ? (isCorrectState ? 'map-country-correct' : 'map-country-incorrect') : ''
                    }`}
                    onMouseEnter={() => setHoveredItem(mappedId)}
                    onMouseLeave={() => setHoveredItem(null)}
                    onClick={(e) => handleEntityClick(mappedId, countryName, e)}
                  />
                );
              })}
            </g>
          )}

          {/* Render Mountains Layer */}
          {showMountains && (
            <g id="mountains-layer">
              {worldMountains.map((mount, i) => {
                const isHovered = hoveredItem === mount.id;
                const isClicked = clickedItem === mount.id;
                const coords = mount.coordinates;

                if (!coords) return null;

                const [projX, projY] = projection(coords) || [0, 0];

                return (
                  <g 
                    key={`mount-${i}`} 
                    className="cursor-pointer"
                    onMouseEnter={() => setHoveredItem(mount.id)}
                    onMouseLeave={() => setHoveredItem(null)}
                    onClick={(e) => handleEntityClick(mount.id, mount.name, e)}
                  >
                    {/* Render Triangle representation for Mountains */}
                    <polygon
                      points={`${projX},${projY - 14} ${projX - 10},${projY + 4} ${projX + 10},${projY + 4}`}
                      fill={isClicked ? (isCorrectState ? '#059669' : '#e11d48') : (isHovered ? '#b45309' : '#78350f')}
                      stroke="#f59e0b"
                      strokeWidth="1"
                      className={isClicked ? (isCorrectState ? 'map-point-correct' : 'map-point-incorrect') : 'transition-transform duration-150'}
                      style={{ transformOrigin: `${projX}px ${projY}px` }}
                    />
                    {(!interactiveMode || clickedItem === mount.id) && (
                      <text
                        x={projX}
                        y={projY + 14}
                        textAnchor="middle"
                        className="text-[9px] font-mono fill-slate-300 bg-slate-900 px-1 pointer-events-none"
                      >
                        {mount.name}
                      </text>
                    )}
                  </g>
                );
              })}
            </g>
          )}

          {/* Render Rivers Layer */}
          {showRivers && (
            <g id="rivers-layer">
              {worldRivers.map((river, i) => {
                const isHovered = hoveredItem === river.id;
                const isClicked = clickedItem === river.id;
                const lineGenerator = d3.line().curve(d3.curveBasis);

                if (!river.coordinatesList) return null;

                const projectedPoints = river.coordinatesList.map(coord => projection(coord) || [0, 0]);
                const pathData = lineGenerator(projectedPoints as [number, number][]);

                // Interactive Click trigger point at the labels
                let strokeColor = isClicked ? (isCorrectState ? '#10b981' : '#f43f5e') : (isHovered ? '#60a5fa' : '#38bdf8');

                return (
                  <g key={`river-${i}`}>
                    <path
                      d={pathData || ''}
                      fill="none"
                      stroke={strokeColor}
                      strokeWidth={isHovered ? "3.5" : "1.8"}
                      className={`transition-all duration-150 cursor-pointer ${
                        isClicked ? (isCorrectState ? 'map-country-correct' : 'map-country-incorrect') : ''
                      }`}
                      onMouseEnter={() => setHoveredItem(river.id)}
                      onMouseLeave={() => setHoveredItem(null)}
                      onClick={(e) => handleEntityClick(river.id, river.name, e)}
                    />
                    {river.coordinates && (!interactiveMode || clickedItem === river.id) && (() => {
                      const [lblX, lblY] = projection(river.coordinates) || [0, 0];
                      return (
                        <text
                          x={lblX}
                          y={lblY - 4}
                          textAnchor="middle"
                          className="text-[8px] font-mono font-bold fill-sky-200 pointer-events-none"
                        >
                          {river.name}
                        </text>
                      );
                    })()}
                  </g>
                );
              })}
            </g>
          )}

          {/* Render Capital Cities Layer */}
          {showCapitals && (
            <g id="capitals-layer">
              {worldCapitals.map((cap, i) => {
                if (!cap.coordinates) return null;
                const [projX, projY] = projection(cap.coordinates) || [0, 0];

                const isHovered = hoveredItem === cap.id;
                const isClicked = clickedItem === cap.id;

                let color = '#fbbf24'; // yellow
                let radius = isHovered ? 6 : 4;

                if (isClicked) {
                  color = isCorrectState ? '#10b981' : '#f43f5e';
                  radius = 7;
                }

                return (
                  <g 
                    key={`cap-${i}`} 
                    className="cursor-pointer"
                    onMouseEnter={() => setHoveredItem(cap.id)}
                    onMouseLeave={() => setHoveredItem(null)}
                    onClick={(e) => handleEntityClick(cap.id, cap.name, e)}
                  >
                    <circle
                      cx={projX}
                      cy={projY}
                      r={radius}
                      fill={color}
                      stroke="#ffffff"
                      strokeWidth="1"
                      className={isClicked ? (isCorrectState ? 'map-point-correct' : 'map-point-incorrect') : 'transition-all duration-150'}
                      style={{ transformOrigin: `${projX}px ${projY}px` }}
                    />
                    {isHovered && (!interactiveMode || clickedItem === cap.id) && (
                      <text
                        x={projX}
                        y={projY - 8}
                        textAnchor="middle"
                        className="text-[9px] font-mono fill-amber-300 font-bold bg-slate-950 pointer-events-none"
                      >
                        {cap.name}
                      </text>
                    )}
                  </g>
                );
              })}
            </g>
          )}
        </svg>

        {/* Floating results overlay HUD */}
        {clickedItem && (
          <div className="absolute bottom-4 left-4 z-20 px-4 py-3 bg-slate-900 border border-white/10 rounded-2xl flex items-center gap-2.5 animate-bounce">
            <span className="text-xl">{isCorrectState ? '✅' : '❌'}</span>
            <div>
              <span className="text-[10px] font-mono tracking-widest text-slate-400 block uppercase">
                {isCorrectState ? 'Juist antwoord!' : 'Fout antwoord!'}
              </span>
              <span className={`text-sm font-extrabold ${isCorrectState ? 'text-emerald-400' : 'text-rose-400'}`}>
                {isCorrectState ? 'Goed gedaan!' : `Dit was niet het gezochte object.`}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
