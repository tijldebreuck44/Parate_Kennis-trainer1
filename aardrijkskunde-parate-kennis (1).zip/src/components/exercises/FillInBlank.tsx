import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Question } from '../../types/geography';
import { Send, CheckCircle2, AlertCircle } from 'lucide-react';
import { validateAnswer } from '../../utils/normalization';
import { getDutchCategoryLabel } from '../../utils/questionDescriptions';

interface FillInBlankProps {
  question: Question;
  onResult: (isCorrect: boolean, inputVal: string) => void;
}

export const FillInBlank: React.FC<FillInBlankProps> = ({ question, onResult }) => {
  const [inputValue, setInputValue] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Focus input on mount and when question changes
  useEffect(() => {
    setInputValue('');
    setIsSubmitted(false);
    setFeedback(null);
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, [question]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || isSubmitted) return;

    setIsSubmitted(true);
    const correct = validateAnswer(
      inputValue,
      question.correctAnswer,
      question.geoItem.alternatives
    );

    setFeedback(correct ? 'correct' : 'wrong');

    setTimeout(() => {
      onResult(correct, inputValue);
      setInputValue('');
      setFeedback(null);
      setIsSubmitted(false);
    }, 2200);
  };

  return (
    <div className="w-full max-w-xl mx-auto flex flex-col gap-6">
      {/* Target Question Context */}
      <div className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-8 text-center shadow-2xl">
        <span className="text-xs font-mono text-blue-400 bg-blue-500/10 px-3 py-1.5 rounded-full uppercase tracking-wider mb-4 inline-block">
          {getDutchCategoryLabel(question.category)}
        </span>
        <h2 className="text-xl text-slate-400 font-semibold">Vul het juiste antwoord in:</h2>
        <p className="text-2xl mt-3 font-black font-sans text-white tracking-tight">
          {question.text}
        </p>

        {question.geoItem.capital && (
          <p className="text-xs text-slate-500 font-mono mt-2">
            Tip: Hoofdstad is {question.geoItem.capital}
          </p>
        )}
      </div>

      {/* Input Action Card */}
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div className="relative">
          <input
            ref={inputRef}
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            disabled={isSubmitted}
            placeholder="Typ je antwoord..."
            className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-5 text-xl text-white font-semibold focus:outline-none focus:border-blue-500 hover:border-white/20 transition-all shadow-inner placeholder-slate-500 backdrop-blur-md"
            autoFocus
          />
          <button
            type="submit"
            disabled={!inputValue.trim() || isSubmitted}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-3 bg-blue-600 hover:bg-blue-500 disabled:bg-white/5 text-white disabled:text-slate-500 rounded-xl transition-all cursor-pointer shadow-md flex items-center justify-center border border-blue-400/30"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </form>

      {/* Floating Interactive HUD feedback message */}
      <AnimatePresence>
        {feedback && (
          <motion.div
            initial={{ opacity: 0, y: 15, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ type: 'spring', stiffness: 450, damping: 25 }}
            className={`flex items-start gap-4 p-5 rounded-2xl border ${
              feedback === 'correct'
                ? 'bg-green-950/80 border-green-500/30 text-green-300 shadow-lg shadow-green-950/20'
                : 'bg-red-950/80 border-red-500/30 text-red-300 shadow-lg shadow-red-950/20'
            }`}
          >
            {feedback === 'correct' ? (
              <>
                <CheckCircle2 className="w-6 h-6 text-green-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-lg text-green-200">Uitstekend!</h4>
                  <p className="text-sm text-green-400/90 font-medium">Je antwoord is helemaal correct.</p>
                </div>
              </>
            ) : (
              <>
                <AlertCircle className="w-6 h-6 text-red-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-lg text-red-200">Helaas, niet helemaal juist</h4>
                  <p className="text-sm text-red-400/95 font-medium">
                    Het gezochte antwoord was:{' '}
                    <span className="font-extrabold text-white underline underline-offset-2">{question.correctAnswer}</span>
                  </p>
                  {question.geoItem.alternatives && question.geoItem.alternatives.length > 0 && (
                    <p className="text-xs text-red-400/70 mt-1 font-mono">
                      Alternatieven: {question.geoItem.alternatives.join(', ')}
                    </p>
                  )}
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
export default FillInBlank;
