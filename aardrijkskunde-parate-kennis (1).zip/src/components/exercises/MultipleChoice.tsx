import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Question } from '../../types/geography';
import { Check, X } from 'lucide-react';
import { getDutchCategoryLabel } from '../../utils/questionDescriptions';

interface MultipleChoiceProps {
  question: Question;
  onResult: (isCorrect: boolean, chosenOption: string) => void;
}

export const MultipleChoice: React.FC<MultipleChoiceProps> = ({ question, onResult }) => {
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);

  const handleSelect = (option: string) => {
    if (isAnswered) return;
    setSelectedOption(option);
    setIsAnswered(true);

    const isCorrect = option === question.correctAnswer;
    setTimeout(() => {
      onResult(isCorrect, option);
      setSelectedOption(null);
      setIsAnswered(false);
    }, 1500);
  };

  return (
    <div className="w-full max-w-2xl mx-auto flex flex-col gap-6">
      {/* Question Card */}
      <div className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-3xl p-8 text-center shadow-2xl relative overflow-hidden text-white">
        <span className="text-xs font-mono text-blue-400 bg-blue-500/10 px-3 py-1.5 rounded-full uppercase tracking-wider mb-4 inline-block">
          {getDutchCategoryLabel(question.category)}
        </span>
        <h2 className="text-2xl md:text-3xl font-black font-sans tracking-tight mt-2">
          {question.text}
        </h2>
      </div>

      {/* Grid of Options */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {question.options?.map((opt) => {
          const isSelected = selectedOption === opt;
          const isCorrectAnswer = opt === question.correctAnswer;
          
          let buttonStyle = "bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 text-slate-200 hover:text-white backdrop-blur-md";
          let icon = null;

          if (isAnswered) {
            if (isCorrectAnswer) {
              buttonStyle = "bg-green-500/20 border-green-500 text-green-300 ring-2 ring-green-500/30";
              icon = <Check className="w-5 h-5 text-green-400 shrink-0" />;
            } else if (isSelected) {
              buttonStyle = "bg-red-500/20 border-red-500 text-red-300 ring-2 ring-red-500/30";
              icon = <X className="w-5 h-5 text-red-400 shrink-0" />;
            } else {
              buttonStyle = "bg-white/5 border-white/5 text-slate-500 pointer-events-none opacity-40";
            }
          }

          return (
            <motion.button
              key={opt}
              whileHover={!isAnswered ? { scale: 1.02, translateY: -2 } : {}}
              whileTap={!isAnswered ? { scale: 0.98 } : {}}
              onClick={() => handleSelect(opt)}
              disabled={isAnswered}
              className={`flex items-center justify-between p-6 rounded-2xl border text-lg font-semibold tracking-tight text-left transition-all duration-300 shadow-sm cursor-pointer ${buttonStyle}`}
            >
              <span>{opt}</span>
              <AnimatePresence>
                {icon && (
                  <motion.div
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0, opacity: 0 }}
                    transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                  >
                    {icon}
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
};
export default MultipleChoice;
