import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GeoItem } from '../../types/geography';
import { RotateCw, ChevronLeft, ChevronRight, Check, X } from 'lucide-react';
import { getClueForGeoItem, getDutchCategoryLabel } from '../../utils/questionDescriptions';

interface FlashcardsProps {
  items: GeoItem[];
  categoryName: string;
  onFinish?: () => void;
}

export const Flashcards: React.FC<FlashcardsProps> = ({ items, categoryName, onFinish }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [knownCount, setKnownCount] = useState(0);
  const [learningCount, setLearningCount] = useState(0);

  useEffect(() => {
    setCurrentIndex(0);
    setIsFlipped(false);
    setKnownCount(0);
    setLearningCount(0);
  }, [items]);

  if (!items || items.length === 0) {
    return (
      <div className="text-center p-8 text-slate-500 font-medium">
        Geen leerkaarten beschikbaar voor deze selectie.
      </div>
    );
  }

  const currentItem = items[currentIndex];

  // Calculate dynamic active-recall front and back texts
  const isCapitalQuery = currentItem.category === 'country' || currentItem.category === 'province';
  const frontText = isCapitalQuery
    ? `Wat is de hoofdstad van ${currentItem.name}?`
    : getClueForGeoItem(currentItem.id, currentItem.name, currentItem.category);
  
  const backTitle = isCapitalQuery
    ? (currentItem.capital || 'Geen hoofdstad')
    : currentItem.name;

  const backSubtitle = isCapitalQuery
    ? `Hoofdstad van ${currentItem.name}`
    : `Type: ${getDutchCategoryLabel(currentItem.category)}`;

  const handleNext = () => {
    setIsFlipped(false);
    setTimeout(() => {
      if (currentIndex < items.length - 1) {
        setCurrentIndex(prev => prev + 1);
      } else {
        // finished full deck
        if (onFinish) onFinish();
        setCurrentIndex(0); // circular fallback
      }
    }, 150);
  };

  const handlePrev = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev - 1 + items.length) % items.length);
    }, 150);
  };

  const handleKnown = () => {
    setKnownCount(c => c + 1);
    handleNext();
  };

  const handleLearning = () => {
    setLearningCount(c => c + 1);
    handleNext();
  };

  return (
    <div className="flex flex-col items-center w-full max-w-xl mx-auto">
      {/* Category Progress HUD Header */}
      <div className="flex justify-between w-full mb-4 px-2 text-sm text-slate-400 font-semibold font-mono">
        <span className="uppercase tracking-wider text-cyan-400">{categoryName}</span>
        <span>{currentIndex + 1} / {items.length} kaarten</span>
      </div>

      {/* 3D Flashcard flip block */}
      <div className="w-full aspect-[4/3] rounded-3xl relative preserve-3d cursor-pointer" onClick={() => setIsFlipped(!isFlipped)}>
        <motion.div
          className="w-full h-full absolute inset-0"
          animate={{ rotateY: isFlipped ? 180 : 0 }}
          transition={{ duration: 0.6, type: 'spring', stiffness: 220, damping: 22 }}
          style={{ transformStyle: 'preserve-3d' }}
        >
          {/* FRONT Side */}
          <div
            className="absolute inset-0 bg-gradient-to-br from-white/10 to-white/5 border border-white/10 backdrop-blur-xl rounded-3xl flex flex-col items-center justify-between shadow-2xl p-8"
            style={{ backfaceVisibility: 'hidden' }}
          >
            <span className="text-xs text-blue-400 font-mono uppercase tracking-widest bg-blue-500/10 px-3 py-1.5 rounded-full inline-block mt-2">
              VRAAG
            </span>
            
            <div className="text-center my-auto flex flex-col gap-2 px-4">
              <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight leading-snug">
                {frontText}
              </h2>
              <p className="text-xs text-slate-400 font-semibold tracking-wider font-mono uppercase mt-2">
                Categorie: {getDutchCategoryLabel(currentItem.category)}
              </p>
            </div>

            <div className="flex items-center gap-2 text-slate-400 text-sm font-mono pb-2">
              <RotateCw className="w-4 h-4 animate-spin-slow text-slate-500" />
              <span>Tik op de kaart om het antwoord te zien</span>
            </div>
          </div>

          {/* BACK Side */}
          <div
            className="absolute inset-0 bg-gradient-to-br from-blue-950/40 to-slate-900/40 border border-blue-500/30 backdrop-blur-xl rounded-3xl flex flex-col items-center justify-between shadow-2xl p-8"
            style={{ backfaceVisibility: 'hidden', transform: 'rotateY(180deg)' }}
          >
            <span className="text-xs text-emerald-400 font-mono uppercase tracking-widest bg-emerald-500/10 px-3 py-1.5 rounded-full inline-block mt-2">
              ANTWOORD
            </span>

            <div className="text-center my-auto px-4">
              <p className="text-xs text-slate-400 uppercase tracking-widest font-mono font-bold mb-2">{backSubtitle}</p>
              <h3 className="text-3xl md:text-4xl font-extrabold text-emerald-300 tracking-tight leading-tight">
                {backTitle}
              </h3>
              {currentItem.alternatives && currentItem.alternatives.length > 0 && (
                <p className="text-sm text-slate-400 font-medium font-mono mt-3">
                  Alternatieven: {currentItem.alternatives.join(', ')}
                </p>
              )}
            </div>

            <div className="flex items-center gap-2 text-blue-400 text-sm font-mono pb-2">
              <RotateCw className="w-4 h-4 text-blue-500" />
              <span>Tik om terug te draaien</span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Review Response Actions */}
      <div className="flex items-center gap-3 mt-8 w-full">
        <button
          onClick={handleLearning}
          className="flex-1 py-4 flex items-center justify-center gap-2 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 rounded-2xl font-bold transition-all text-rose-300 shadow-sm cursor-pointer"
        >
          <X className="w-5 h-5" />
          <span>Moet ik herhalen ({learningCount})</span>
        </button>
        <button
          onClick={handleKnown}
          className="flex-1 py-4 flex items-center justify-center gap-2 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 rounded-2xl font-bold transition-all text-emerald-300 shadow-sm cursor-pointer"
        >
          <Check className="w-5 h-5" />
          <span>Ken ik wel ({knownCount})</span>
        </button>
      </div>

      {/* Previous / Next deck controls */}
      <div className="flex items-center justify-between w-full mt-4 px-2">
        <button
          onClick={handlePrev}
          className="p-3 text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/10 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 font-semibold text-sm"
        >
          <ChevronLeft className="w-5 h-5" />
          <span>Vorige</span>
        </button>
        <button
          onClick={handleNext}
          className="p-3 text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/10 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 font-semibold text-sm"
        >
          <span>Sla over</span>
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
export default Flashcards;
