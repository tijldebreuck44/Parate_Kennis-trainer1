import React, { useEffect, useState, useRef } from 'react';
import * as d3 from 'd3';
import * as topojson from 'topojson-client';
import { europeCapitals, europeRivers, europeMountains, GeoFeature } from '../data/geoData';
import { Layers } from 'lucide-react';

interface EuropeMapProps {
  activeQuestion?: {
    id: string;
    targetId: string;
    correctAnswer: string;
    geoItem?: any;
    category?: string;
  } | null;
  onResult?: (isCorrect: boolean, chosenVal: string) => void;
  interactiveMode?: boolean;
}

// Map numeric IDs from world-atlas to Europe IDs in europe.json
const europeIdMap: Record<number, string> = {
  528: "eu-l-ned", // Netherlands
  56:  "eu-l-bel", // Belgium
  442: "eu-l-lux", // Luxembourg
  250: "eu-l-fra", // France
  276: "eu-l-dui", // Germany
  826: "eu-l-gbr", // United Kingdom
  372: "eu-l-ier", // Ireland
  380: "eu-l-ita", // Italy
  724: "eu-l-spa", // Spain
  620: "eu-l-por", // Portugal
  756: "eu-l-zwi-capital", // Switzerland (Bern)
  40:  "eu-l-oas", // Austria (Wenen)
  616: "eu-l-pol", // Poland
  203: "eu-l-tsj", // Czech Republic
  703: "eu-l-slo", // Slovakia
  348: "eu-l-hon", // Hungary
  191: "eu-l-kro", // Croatia
  705: "eu-l-slv", // Slovenia
  688: "eu-l-ser", // Serbia
  499: "eu-l-mon", // Montenegro
  70:  "eu-l-bos", // Bosnia
  807: "eu-l-nma", // North Macedonia
  300: "eu-l-gri", // Greece
  100: "eu-l-bul", // Bulgaria
  642: "eu-l-roe", // Romania
  498: "eu-l-mol", // Moldova
  804: "eu-l-oek", // Ukraine
  112: "eu-l-wit", // Belarus
  440: "eu-l-lit", // Lithuania
  428: "eu-l-let", // Latvia
  233: "eu-l-est", // Estonia
  643: "eu-l-rus", // Russia
  470: "eu-l-mal", // Malta
  196: "eu-l-cyp", // Cyprus
  208: "eu-l-dan", // Denmark
  578: "eu-l-noo", // Norway
  752: "eu-l-zwe", // Sweden
  246: "eu-l-fin", // Finland
  352: "eu-l-ijsl"  // Iceland
};

export default function EuropeMap({ activeQuestion, onResult, interactiveMode = true }: EuropeMapProps) {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [countriesGeo, setCountriesGeo] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const [clickedItem, setClickedItem] = useState<string | null>(null);
  const [isCorrectState, setIsCorrectState] = useState<boolean | null>(null);

  // Active layers switches
  const [showCountries, setShowCountries] = useState(true);
  const [showCapitals, setShowCapitals] = useState(true);
  const [showRivers, setShowRivers] = useState(true);
  const [showMountains, setShowMountains] = useState(true);

  // Fetch geographic boundaries
  useEffect(() => {
    fetch('https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json')
      .then(res => res.json())
      .then(data => {
        const countriesArr = topojson.feature(data, data.objects.countries) as any;
        // Filter out purely European geometries for better rendering speeds
        const europeanGeometries = countriesArr.features.filter((f: any) => europeIdMap[Number(f.id)]);
        setCountriesGeo(europeanGeometries || []);
        setLoading(false);
      })
      .catch(err => {
        console.error("Error loading europe borders", err);
        setLoading(false);
      });
  }, []);

  // Map settings and sizes
  const width = 800;
  const height = 460;

  // Projection setup: Albers or Conic Conformal works beautifully for Europe
  const projection = d3.geoConicConformal()
    .center([11, 52]) // center of Europe lon/lat
    .rotate([0, 0])
    .parallels([35, 65])
    .scale(550) // Zoomed in heavily on Europe
    .translate([width / 2, height / 2 + 30]);

  const pathGenerator = d3.geoPath().projection(projection);

  // Clear states when target changes
  useEffect(() => {
    setClickedItem(null);
    setIsCorrectState(null);
  }, [activeQuestion]);

  const handleEntityClick = (itemId: string, itemName: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!interactiveMode || clickedItem) return;

    setClickedItem(itemId);

    if (activeQuestion) {
      const isCorrect = itemId === activeQuestion.targetId || 
                        itemName.toLowerCase() === activeQuestion.correctAnswer.toLowerCase();
      setIsCorrectState(isCorrect);

      if (onResult) {
        onResult(isCorrect, itemName);
      }
    }
  };

  return (
    <div className="space-y-4">
      {/* Map Control Layer Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-md">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-blue-400" />
          <span className="text-xs font-mono font-bold uppercase text-slate-400">Zichtbare Lagen:</span>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button 
            onClick={() => setShowCountries(p => !p)}
            className={`px-3 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
              showCountries ? 'bg-blue-600/20 border-blue-400 text-blue-300' : 'bg-transparent border-white/5 text-slate-500 hover:text-slate-300'
            }`}
          >
            🌍 Europees Landen
          </button>
          <button 
            onClick={() => setShowCapitals(p => !p)}
            className={`px-3 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
              showCapitals ? 'bg-amber-600/20 border-amber-400 text-amber-300' : 'bg-transparent border-white/5 text-slate-500 hover:text-slate-300'
            }`}
          >
            🏛️ Hoofdsteden
          </button>
          <button 
            onClick={() => setShowRivers(p => !p)}
            className={`px-3 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
              showRivers ? 'bg-sky-600/20 border-sky-400 text-sky-300' : 'bg-transparent border-white/5 text-slate-500 hover:text-slate-300'
            }`}
          >
            🌊 Wateren / Rivieren
          </button>
          <button 
            onClick={() => setShowMountains(p => !p)}
            className={`px-3 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
              showMountains ? 'bg-emerald-600/20 border-emerald-400 text-emerald-300' : 'bg-transparent border-white/5 text-slate-500 hover:text-slate-300'
            }`}
          >
            ⛰️ Gebergten
          </button>
        </div>
      </div>

      {/* Main Map SVG Area */}
      <div className="relative border border-white/10 rounded-3xl overflow-hidden bg-slate-950/85 shadow-2xl">
        {loading && (
          <div className="absolute inset-0 bg-slate-950/90 flex flex-col items-center justify-center space-y-3 z-30">
            <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-xs font-mono text-slate-400">Cartografie van Europa laden...</p>
          </div>
        )}

        {/* HUD Game Instruction */}
        {interactiveMode && activeQuestion && (
          <div className="absolute top-4 left-4 z-20 px-4 py-2 bg-slate-900/90 border border-white/10 rounded-xl backdrop-blur-md shadow-lg">
            <span className="text-[10px] font-mono font-bold uppercase text-blue-400 block tracking-widest">EUROPESE VRAAG:</span>
            <span className="text-base font-extrabold tracking-tight text-white block mt-0.5">
              {activeQuestion.geoItem?.capital && activeQuestion.category === 'capital'
                ? `Waar ligt de hoofdstad van dit land: ${activeQuestion.correctAnswer}?`
                : `Waar ligt het object: ${activeQuestion.geoItem?.name || activeQuestion.correctAnswer}?`
              }
            </span>
          </div>
        )}

        <svg 
          ref={svgRef}
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto max-h-[500px] select-none text-slate-100"
          style={{ cursor: interactiveMode ? 'crosshair' : 'grab' }}
        >
          {/* Cyan/Blue sea background color */}
          <rect width={width} height={height} fill="#0d1b2a44" />

          {/* Render Countries Layer */}
          {showCountries && (
            <g id="europe-countries-layer">
              {countriesGeo.map((feature, i) => {
                const numericId = Number(feature.id);
                const mappedId = europeIdMap[numericId] || `country-${numericId}`;
                const countryName = feature.properties.name || "Land";

                let fill = '#1e293b';
                let stroke = '#334155';
                
                const isHovered = hoveredItem === mappedId;
                const isClicked = clickedItem === mappedId;

                if (isHovered) {
                  fill = '#2563eb';
                }

                if (isClicked) {
                  fill = isCorrectState ? '#10b981' : '#f43f5e';
                }

                return (
                  <path
                    key={`euro-country-${i}`}
                    d={pathGenerator(feature) || ''}
                    fill={fill}
                    stroke={stroke}
                    strokeWidth="0.7"
                    className={`transition-colors duration-155 cursor-pointer ${
                      isClicked ? (isCorrectState ? 'map-country-correct' : 'map-country-incorrect') : ''
                    }`}
                    onMouseEnter={() => setHoveredItem(mappedId)}
                    onMouseLeave={() => setHoveredItem(null)}
                    onClick={(e) => handleEntityClick(mappedId, countryName, e)}
                  />
                );
              })}
            </g>
          )}

          {/* Render Mountains Layer */}
          {showMountains && (
            <g id="europe-mountains-layer">
              {europeMountains.map((mount, i) => {
                const isHovered = hoveredItem === mount.id;
                const isClicked = clickedItem === mount.id;
                const coords = mount.coordinates;

                if (!coords) return null;

                const [projX, projY] = projection(coords) || [0, 0];

                return (
                  <g 
                    key={`euro-mount-${i}`}
                    className="cursor-pointer"
                    onMouseEnter={() => setHoveredItem(mount.id)}
                    onMouseLeave={() => setHoveredItem(null)}
                    onClick={(e) => handleEntityClick(mount.id, mount.name, e)}
                  >
                    <polygon
                      points={`${projX},${projY - 14} ${projX - 10},${projY + 4} ${projX + 10},${projY + 4}`}
                      fill={isClicked ? (isCorrectState ? '#059669' : '#e11d48') : (isHovered ? '#b45309' : '#78350f')}
                      stroke="#fbbf24"
                      strokeWidth="1"
                      className={isClicked ? (isCorrectState ? 'map-point-correct' : 'map-point-incorrect') : 'transition-transform duration-150'}
                      style={{ transformOrigin: `${projX}px ${projY}px` }}
                    />
                    {(!interactiveMode || clickedItem === mount.id) && (
                      <text
                        x={projX}
                        y={projY + 12}
                        textAnchor="middle"
                        className="text-[9px] font-mono fill-slate-300 pointer-events-none"
                      >
                        {mount.name}
                      </text>
                    )}
                  </g>
                );
              })}
            </g>
          )}

          {/* Render Rivers Layer */}
          {showRivers && (
            <g id="europe-rivers-layer">
              {europeRivers.map((river, i) => {
                const isHovered = hoveredItem === river.id;
                const isClicked = clickedItem === river.id;
                const lineGenerator = d3.line().curve(d3.curveBasis);

                if (!river.coordinatesList) return null;

                const projectedPoints = river.coordinatesList.map(coord => projection(coord) || [0, 0]);
                const pathData = lineGenerator(projectedPoints as [number, number][]);

                let strokeColor = isClicked ? (isCorrectState ? '#10b981' : '#f43f5e') : (isHovered ? '#60a5fa' : '#0284c7');

                return (
                  <g key={`euro-river-${i}`}>
                    <path
                      d={pathData || ''}
                      fill="none"
                      stroke={strokeColor}
                      strokeWidth={isHovered ? "3.2" : "1.6"}
                      className={`transition-all duration-150 cursor-pointer ${
                        isClicked ? (isCorrectState ? 'map-country-correct' : 'map-country-incorrect') : ''
                      }`}
                      onMouseEnter={() => setHoveredItem(river.id)}
                      onMouseLeave={() => setHoveredItem(null)}
                      onClick={(e) => handleEntityClick(river.id, river.name, e)}
                    />
                    {river.coordinates && (!interactiveMode || clickedItem === river.id) && (() => {
                      const [lblX, lblY] = projection(river.coordinates) || [0, 0];
                      return (
                        <text
                          x={lblX}
                          y={lblY - 4}
                          textAnchor="middle"
                          className="text-[8px] font-mono font-medium fill-sky-200 pointer-events-none"
                        >
                          {river.name}
                        </text>
                      );
                    })()}
                  </g>
                );
              })}
            </g>
          )}

          {/* Render Capitals Layer */}
          {showCapitals && (
            <g id="europe-capitals-layer" className="transition-all">
              {europeCapitals.map((cap, i) => {
                if (!cap.coordinates) return null;
                const [projX, projY] = projection(cap.coordinates) || [0, 0];

                const isHovered = hoveredItem === cap.id;
                const isClicked = clickedItem === cap.id;

                let color = '#fbbf24';
                let radius = isHovered ? 6 : 3.5;

                if (isClicked) {
                  color = isCorrectState ? '#10b981' : '#f43f5e';
                  radius = 7;
                }

                return (
                  <g 
                    key={`euro-cap-${i}`}
                    className="cursor-pointer"
                    onMouseEnter={() => setHoveredItem(cap.id)}
                    onMouseLeave={() => setHoveredItem(null)}
                    onClick={(e) => handleEntityClick(cap.id, cap.name, e)}
                  >
                    <circle
                      cx={projX}
                      cy={projY}
                      r={radius}
                      fill={color}
                      stroke="#ffffff"
                      strokeWidth="0.8"
                      className={isClicked ? (isCorrectState ? 'map-point-correct' : 'map-point-incorrect') : 'transition-all duration-150'}
                      style={{ transformOrigin: `${projX}px ${projY}px` }}
                    />
                    {isHovered && (!interactiveMode || clickedItem === cap.id) && (
                      <text
                        x={projX}
                        y={projY - 8}
                        textAnchor="middle"
                        className="text-[9px] font-mono font-bold fill-amber-300 bg-slate-900 px-1 pointer-events-none"
                      >
                        {cap.name}
                      </text>
                    )}
                  </g>
                );
              })}
            </g>
          )}
        </svg>

        {clickedItem && (
          <div className="absolute bottom-4 left-4 z-20 px-4 py-3 bg-slate-900 border border-white/10 rounded-2xl flex items-center gap-2.5 animate-bounce">
            <span className="text-xl">{isCorrectState ? '✅' : '❌'}</span>
            <div>
              <span className="text-[10px] font-mono tracking-widest text-slate-400 block uppercase">
                {isCorrectState ? 'Europa Correct!' : 'Antwoord niet juist'}
              </span>
              <span className={`text-sm font-extrabold ${isCorrectState ? 'text-emerald-400' : 'text-rose-400'}`}>
                {isCorrectState ? 'Uitmuntend!' : 'Kijk goed op de kaart.'}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
