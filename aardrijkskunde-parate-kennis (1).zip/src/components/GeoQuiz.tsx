import React, { useState, useEffect } from 'react';
import WorldMap from './WorldMap';
import EuropeMap from './EuropeMap';
import BelgiumMap from './BelgiumMap';
import { worldCapitals, worldRivers, worldMountains, europeCapitals, europeRivers, europeMountains, belgiumRivers, GeoFeature } from '../data/geoData';
import belgiumJSON from '../data/belgium.json';
import europeJSON from '../data/europe.json';
import worldJSON from '../data/world.json';
import { Compass, Trophy, RotateCcw, ArrowRight, ShieldCheck, Map, HelpCircle } from 'lucide-react';

export default function GeoQuiz() {
  const [region, setRegion] = useState<'world' | 'europe' | 'belgium'>('world');
  const [category, setCategory] = useState<'country' | 'capital' | 'river' | 'mountain'>('country');

  // Score states
  const [score, setScore] = useState(0);
  const [total, setTotal] = useState(0);
  
  // Quiz Flow
  const [currentQuestion, setCurrentQuestion] = useState<{
    id: string;
    targetId: string;
    correctAnswer: string;
    category: string;
    geoItem: any;
  } | null>(null);

  const [hasAnswered, setHasAnswered] = useState(false);
  const [answerSuccess, setAnswerSuccess] = useState<boolean | null>(null);
  const [userSelectedName, setUserSelectedName] = useState('');

  // Auto generate a question on mount or change of region/category
  useEffect(() => {
    generateNewQuestion();
  }, [region, category]);

  // Handle region shifts
  const handleRegionChange = (newReg: 'world' | 'europe' | 'belgium') => {
    setRegion(newReg);
    // Reset category to supported one on belgium
    if (newReg === 'belgium') {
      if (category === 'mountain' || category === 'country') {
        setCategory('capital'); // capitals refer to provincial capitals in belgium text
      }
    } else {
      setCategory('country');
    }
  };

  const generateNewQuestion = () => {
    setHasAnswered(false);
    setAnswerSuccess(null);
    setUserSelectedName('');

    let pool: any[] = [];

    if (region === 'world') {
      if (category === 'country') {
        pool = worldJSON.countries || [];
      } else if (category === 'capital') {
        pool = worldCapitals;
      } else if (category === 'river') {
        pool = worldRivers;
      } else if (category === 'mountain') {
        pool = worldMountains;
      }
    } else if (region === 'europe') {
      if (category === 'country') {
        // use countries with mappings
        pool = europeJSON.countries || [];
      } else if (category === 'capital') {
        pool = europeCapitals;
      } else if (category === 'river') {
        pool = europeRivers;
      } else if (category === 'mountain') {
        pool = europeMountains;
      }
    } else if (region === 'belgium') {
      // Belgium has provinces, provincial capitals and Belgian rivers
      if (category === 'capital') {
        pool = belgiumJSON.provinces || []; // each has capital
      } else if (category === 'river') {
        pool = belgiumRivers;
      } else {
        pool = belgiumJSON.provinces || []; // default to provinces
      }
    }

    if (pool.length === 0) {
      setCurrentQuestion(null);
      return;
    }

    // Pick a random target
    const target = pool[Math.floor(Math.random() * pool.length)];
    const qId = Math.random().toString();

    let targetId = target.id;
    let correctAnswer = target.name || target.naam || '';
    
    if (category === 'capital' && target.capital) {
      correctAnswer = target.capital;
      targetId = target.id.startsWith('capital-') ? target.id : `capital-${target.id}`;
    }

    setCurrentQuestion({
      id: qId,
      targetId,
      correctAnswer,
      category,
      geoItem: target
    });
  };

  const handleResult = (isCorrect: boolean, chosenLabel: string) => {
    if (hasAnswered) return;
    setHasAnswered(true);
    setAnswerSuccess(isCorrect);
    setUserSelectedName(chosenLabel);
    
    setTotal(t => t + 1);
    if (isCorrect) {
      setScore(s => s + 1);
    }
  };

  const resetScore = () => {
    setScore(0);
    setTotal(0);
    generateNewQuestion();
  };

  return (
    <div className="space-y-6">
      {/* Title Header Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 bg-gradient-to-r from-blue-900/40 via-purple-900/20 to-slate-900/40 border border-white/10 rounded-3xl backdrop-blur-md">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-1 px-2.5 bg-blue-500/10 text-blue-300 border border-blue-500/20 rounded-md text-[10px] uppercase font-mono tracking-widest font-extrabold flex items-center gap-1">
              <Compass className="w-3 h-3 animate-spin duration-1000" /> KAART QUIZ MODE
            </span>
          </div>
          <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2 mt-1">
            Topografische Landkaart Training
          </h2>
          <p className="text-sm font-mono text-slate-400">
            Draai aan het kompas en klik interactief op de juiste geografische coördinaten!
          </p>
        </div>

        {/* Live Score Counter */}
        <div className="flex items-center gap-4 bg-slate-950/60 p-4 border border-white/5 rounded-2xl">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-xl">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-mono uppercase text-slate-500 block">Huidige Score</span>
              <span className="text-xl font-mono font-extrabold text-white">
                {score} <span className="text-slate-500 text-sm">/ {total}</span>
              </span>
            </div>
          </div>
          <button 
            onClick={resetScore}
            className="p-2 text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            title="Reset Score"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Region & Layers select selectors */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Region Panel */}
        <div className="p-4 bg-slate-900/40 border border-white/10 rounded-2xl space-y-3">
          <div className="flex items-center gap-2 pb-1 border-b border-white/5">
            <Map className="w-4 h-4 text-blue-400" />
            <h3 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">Kies Regio / Kaart:</h3>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => handleRegionChange('world')}
              className={`py-2 px-3 text-xs font-extrabold border rounded-xl transition-all cursor-pointer ${
                region === 'world' 
                  ? 'bg-blue-600 border-blue-400 text-white shadow-lg shadow-blue-500/15' 
                  : 'bg-transparent border-white/10 text-slate-400 hover:text-white hover:border-white/20'
              }`}
            >
              🌐 Wereld
            </button>
            <button
              onClick={() => handleRegionChange('europe')}
              className={`py-2 px-3 text-xs font-extrabold border rounded-xl transition-all cursor-pointer ${
                region === 'europe'
                  ? 'bg-blue-600 border-blue-400 text-white shadow-lg shadow-blue-500/15'
                  : 'bg-transparent border-white/10 text-slate-400 hover:text-white hover:border-white/20'
              }`}
            >
              🇪🇺 Europa
            </button>
            <button
              onClick={() => handleRegionChange('belgium')}
              className={`py-2 px-3 text-xs font-extrabold border rounded-xl transition-all cursor-pointer ${
                region === 'belgium'
                  ? 'bg-blue-600 border-blue-400 text-white shadow-lg shadow-blue-500/15'
                  : 'bg-transparent border-white/10 text-slate-400 hover:text-white hover:border-white/20'
              }`}
            >
              🇧🇪 België
            </button>
          </div>
        </div>

        {/* Quiz Category select panel */}
        <div className="p-4 bg-slate-900/40 border border-white/10 rounded-2xl space-y-3">
          <div className="flex items-center gap-2 pb-1 border-b border-white/5">
            <HelpCircle className="w-4 h-4 text-purple-400" />
            <h3 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">Wat wil je raden?</h3>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
            <button
              onClick={() => setCategory('country')}
              disabled={region === 'belgium'}
              className={`py-2 px-2 text-xs font-extrabold border rounded-xl transition-all cursor-pointer ${
                region === 'belgium' ? 'opacity-30 cursor-not-allowed' :
                category === 'country'
                  ? 'bg-purple-600 border-purple-400 text-white shadow-lg shadow-purple-500/15'
                  : 'bg-transparent border-white/10 text-slate-400 hover:text-white hover:border-white/20'
              }`}
              title={region === 'belgium' ? 'Niet beschikbaar voor België' : 'Raad landen'}
            >
              🌍 Landen
            </button>
            <button
              onClick={() => setCategory('capital')}
              className={`py-2 px-2 text-xs font-extrabold border rounded-xl transition-all cursor-pointer ${
                category === 'capital'
                  ? 'bg-purple-600 border-purple-400 text-white shadow-lg shadow-purple-500/15'
                  : 'bg-transparent border-white/10 text-slate-400 hover:text-white hover:border-white/20'
              }`}
            >
              🏛️ Hoofdsteden
            </button>
            <button
              onClick={() => setCategory('river')}
              className={`py-2 px-2 text-xs font-extrabold border rounded-xl transition-all cursor-pointer ${
                category === 'river'
                  ? 'bg-purple-600 border-purple-400 text-white shadow-lg shadow-purple-500/15'
                  : 'bg-transparent border-white/10 text-slate-400 hover:text-white hover:border-white/20'
              }`}
            >
              🌊 Rivieren
            </button>
            <button
              onClick={() => setCategory('mountain')}
              disabled={region === 'belgium'}
              className={`py-2 px-2 text-xs font-extrabold border rounded-xl transition-all cursor-pointer ${
                region === 'belgium' ? 'opacity-30 cursor-not-allowed' :
                category === 'mountain'
                  ? 'bg-purple-600 border-purple-400 text-white shadow-lg shadow-purple-500/15'
                  : 'bg-transparent border-white/10 text-slate-400 hover:text-white hover:border-white/20'
              }`}
              title={region === 'belgium' ? 'Niet beschikbaar voor België' : 'Raad gebergten'}
            >
              ⛰️ Gebergten
            </button>
          </div>
        </div>
      </div>

      {/* Active Question banner HUD & Next Trigger controls */}
      {currentQuestion && (
        <div className="flex flex-col sm:flex-row items-center justify-between p-4 bg-slate-900/60 border border-white/10 rounded-2xl gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600/10 border border-blue-400/20 rounded-xl flex items-center justify-center text-xl">
              🎯
            </div>
            <div>
              <span className="text-[9px] font-mono text-slate-400 uppercase tracking-widest block">Actieve Quiz Vraag:</span>
              <span className="text-sm font-bold text-white">
                {category === 'capital' 
                  ? `Klik op de hoofdstad: ${currentQuestion.correctAnswer}`
                  : `Klik op het geografisch object: ${currentQuestion.correctAnswer}`
                }
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {hasAnswered && (
              <span className={`px-3 py-1 text-xs font-extrabold font-mono uppercase rounded-lg ${
                answerSuccess ? 'bg-emerald-500/20 border border-emerald-400 text-emerald-300' : 'bg-rose-500/20 border border-rose-400 text-rose-300'
              }`}>
                {answerSuccess ? 'Uitstekend! +1pt' : `Onjuist!`}
              </span>
            )}

            <button
              disabled={!hasAnswered}
              onClick={generateNewQuestion}
              className={`py-2 px-5 text-xs font-extrabold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer ${
                hasAnswered 
                  ? 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-500/20' 
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              Volgende vraag <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Map Rendering Container */}
      <div>
        {region === 'world' && (
          <WorldMap 
            activeQuestion={currentQuestion} 
            onResult={handleResult} 
          />
        )}
        {region === 'europe' && (
          <EuropeMap 
            activeQuestion={currentQuestion} 
            onResult={handleResult} 
          />
        )}
        {region === 'belgium' && (
          <BelgiumMap 
            activeQuestion={currentQuestion} 
            onResult={handleResult} 
          />
        )}
      </div>

      {/* Helpful Instructions footer */}
      <div className="p-4 bg-slate-950/40 border border-white/5 rounded-2xl flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <span className="text-xs font-bold text-slate-300">Interactieve Training Tips:</span>
          <p className="text-[11px] text-slate-400 leading-relaxed font-mono">
            - Je kunt de kaartlagen aan- of uitzetten met de knoppen boven de kaart om de quiz uitdagender of makkelijker te maken.<br />
            - Gebergten zijn gemarkeerd als bruine driehoeken, Hoofdsteden als glanzend gele bollen, en Rivieren als lichtblauwe stromen.<br />
            - Klik direct op de respectievelijke objecten of landenvakken om een antwoord in te dienen!
          </p>
        </div>
      </div>
    </div>
  );
}
