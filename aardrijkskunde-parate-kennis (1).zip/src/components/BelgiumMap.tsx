import React, { useEffect, useState, useRef } from 'react';
import * as d3 from 'd3';
import provincesData from '../data/belgium.json';
import { belgiumRivers, GeoFeature } from '../data/geoData';
import { Layers } from 'lucide-react';

interface BelgiumMapProps {
  activeQuestion?: {
    id: string;
    targetId: string;
    correctAnswer: string;
    geoItem?: any;
    category?: string;
  } | null;
  onResult?: (isCorrect: boolean, chosenVal: string) => void;
  interactiveMode?: boolean;
}

export default function BelgiumMap({ activeQuestion, onResult, interactiveMode = true }: BelgiumMapProps) {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const [clickedItem, setClickedItem] = useState<string | null>(null);
  const [isCorrectState, setIsCorrectState] = useState<boolean | null>(null);

  // Active layers switches
  const [showProvinces, setShowProvinces] = useState(true);
  const [showCapitals, setShowCapitals] = useState(true);
  const [showRivers, setShowRivers] = useState(true);

  // Map settings and sizes
  const width = 800;
  const height = 460;

  // Projection setup for Belgium: Mercator centered at [4.4699, 50.5039]
  const projection = d3.geoMercator()
    .center([4.4699, 50.5039])
    .scale(10000) // Heavily centered on Belgium
    .translate([width / 2, height / 2 + 10]);

  // Clear states when target changes
  useEffect(() => {
    setClickedItem(null);
    setIsCorrectState(null);
  }, [activeQuestion]);

  const handleEntityClick = (itemId: string, itemName: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!interactiveMode || clickedItem) return;

    setClickedItem(itemId);

    if (activeQuestion) {
      const isCorrect = itemId === activeQuestion.targetId || 
                        itemName.toLowerCase() === activeQuestion.correctAnswer.toLowerCase();
      setIsCorrectState(isCorrect);

      if (onResult) {
        onResult(isCorrect, itemName);
      }
    }
  };

  // Build polygon path drawing utilizing projected coordinates list
  const getPolygonPathData = (polygonPoints: [number, number][]) => {
    if (!polygonPoints) return '';
    const projected = polygonPoints.map(point => {
      const projectedPoint = projection(point);
      return projectedPoint ? `${projectedPoint[0]},${projectedPoint[1]}` : '';
    }).filter(Boolean);
    return `M ${projected.join(' L ')} Z`;
  };

  return (
    <div className="space-y-4">
      {/* Map Control Layer Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-md">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-blue-400" />
          <span className="text-xs font-mono font-bold uppercase text-slate-400">Zichtbare Lagen:</span>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button 
            onClick={() => setShowProvinces(p => !p)}
            className={`px-3 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
              showProvinces ? 'bg-blue-600/20 border-blue-400 text-blue-300' : 'bg-transparent border-white/5 text-slate-500 hover:text-slate-300'
            }`}
          >
            🇧🇪 Provincies
          </button>
          <button 
            onClick={() => setShowCapitals(p => !p)}
            className={`px-3 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
              showCapitals ? 'bg-amber-600/20 border-amber-400 text-amber-300' : 'bg-transparent border-white/5 text-slate-500 hover:text-slate-300'
            }`}
          >
            🏛️ Provinciehoofdsteden
          </button>
          <button 
            onClick={() => setShowRivers(p => !p)}
            className={`px-3 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
              showRivers ? 'bg-sky-600/20 border-sky-400 text-sky-300' : 'bg-transparent border-white/5 text-slate-500 hover:text-slate-300'
            }`}
          >
            🌊 Rivieren
          </button>
        </div>
      </div>

      {/* Main Map SVG Area */}
      <div className="relative border border-white/10 rounded-3xl overflow-hidden bg-slate-950/85 shadow-2xl">
        {/* HUD Game Instruction */}
        {interactiveMode && activeQuestion && (
          <div className="absolute top-4 left-4 z-20 px-4 py-2 bg-slate-900/90 border border-white/10 rounded-xl backdrop-blur-md shadow-lg">
            <span className="text-[10px] font-mono font-bold uppercase text-blue-400 block tracking-widest">BELGISCHE VRAAG:</span>
            <span className="text-base font-extrabold tracking-tight text-white block mt-0.5">
              {activeQuestion.geoItem?.capital && activeQuestion.category === 'capital'
                ? `Klik op de provinciehoofdstad: ${activeQuestion.correctAnswer}?`
                : `Klik op de provincie/rivier: ${activeQuestion.geoItem?.name || activeQuestion.correctAnswer}?`
              }
            </span>
          </div>
        )}

        <svg 
          ref={svgRef}
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto max-h-[500px] select-none text-slate-100"
          style={{ cursor: interactiveMode ? 'crosshair' : 'grab' }}
        >
          {/* Indigo backdrop representation of surrounding border region */}
          <rect width={width} height={height} fill="#0d1b2a22" />

          {/* Render Provinces Layer */}
          {showProvinces && (
            <g id="provinces-layer">
              {provincesData.provinces.map((province: any, i) => {
                const provId = province.id;
                const provName = province.name;
                const pathData = getPolygonPathData(province.polygon);

                let fill = '#1e293b';
                let stroke = '#475569';
                
                const isHovered = hoveredItem === provId;
                const isClicked = clickedItem === provId;

                if (isHovered) {
                  fill = '#2563eb';
                }

                if (isClicked) {
                  fill = isCorrectState ? '#10b981' : '#f43f5e';
                }

                return (
                  <path
                    key={`province-${i}`}
                    d={pathData}
                    fill={fill}
                    stroke={stroke}
                    strokeWidth="1.2"
                    className="transition-colors duration-150 cursor-pointer"
                    onMouseEnter={() => setHoveredItem(provId)}
                    onMouseLeave={() => setHoveredItem(null)}
                    onClick={(e) => handleEntityClick(provId, provName, e)}
                  />
                );
              })}
            </g>
          )}

          {/* Render Rivers Layer */}
          {showRivers && (
            <g id="belgium-rivers-layer">
              {belgiumRivers.map((river, i) => {
                const isHovered = hoveredItem === river.id;
                const isClicked = clickedItem === river.id;
                const lineGenerator = d3.line().curve(d3.curveBasis);

                if (!river.coordinatesList) return null;

                const projectedPoints = river.coordinatesList.map(coord => projection(coord) || [0, 0]);
                const pathData = lineGenerator(projectedPoints as [number, number][]);

                let strokeColor = isClicked ? (isCorrectState ? '#10b981' : '#f43f5e') : (isHovered ? '#60a5fa' : '#2563eb');

                return (
                  <g key={`bel-river-${i}`}>
                    <path
                      d={pathData || ''}
                      fill="none"
                      stroke={strokeColor}
                      strokeWidth={isHovered ? "4" : "2"}
                      className="transition-all duration-155 cursor-pointer"
                      onMouseEnter={() => setHoveredItem(river.id)}
                      onMouseLeave={() => setHoveredItem(null)}
                      onClick={(e) => handleEntityClick(river.id, river.name, e)}
                    />
                    {river.coordinates && (!interactiveMode || clickedItem === river.id) && (() => {
                      const [lblX, lblY] = projection(river.coordinates) || [0, 0];
                      return (
                        <text
                          x={lblX}
                          y={lblY - 4}
                          textAnchor="middle"
                          className="text-[9px] font-mono font-bold fill-indigo-300 pointer-events-none"
                        >
                          {river.name}
                        </text>
                      );
                    })()}
                  </g>
                );
              })}
            </g>
          )}

          {/* Render Capitals Layer */}
          {showCapitals && (
            <g id="belgium-capitals-layer">
              {provincesData.provinces.map((prov: any, i) => {
                if (!prov.coordinates) return null;
                const [projX, projY] = projection(prov.coordinates) || [0, 0];

                const isHovered = hoveredItem === `capital-${prov.id}`;
                const isClicked = clickedItem === `capital-${prov.id}`;

                let color = '#fbbf24';
                let radius = isHovered ? 6 : 4;

                if (isClicked) {
                  color = isCorrectState ? '#10b981' : '#f43f5e';
                  radius = 7;
                }

                return (
                  <g 
                    key={`bel-cap-${i}`}
                    className="cursor-pointer"
                    onMouseEnter={() => setHoveredItem(`capital-${prov.id}`)}
                    onMouseLeave={() => setHoveredItem(null)}
                    onClick={(e) => handleEntityClick(`capital-${prov.id}`, prov.capital, e)}
                  >
                    <circle
                      cx={projX}
                      cy={projY}
                      r={radius}
                      fill={color}
                      stroke="#ffffff"
                      strokeWidth="1"
                    />
                    {(!interactiveMode || clickedItem === `capital-${prov.id}`) && (
                      <text
                        x={projX}
                        y={projY - 8}
                        textAnchor="middle"
                        className="text-[9px] font-mono font-bold fill-slate-200 bg-slate-900 pointer-events-none"
                      >
                        {prov.capital}
                      </text>
                    )}
                  </g>
                );
              })}
            </g>
          )}
        </svg>

        {clickedItem && (
          <div className="absolute bottom-4 left-4 z-20 px-4 py-3 bg-slate-900 border border-white/10 rounded-2xl flex items-center gap-2.5 animate-bounce">
            <span className="text-xl">{isCorrectState ? '✅' : '❌'}</span>
            <div>
              <span className="text-[10px] font-mono tracking-widest text-slate-400 block uppercase">
                {isCorrectState ? 'België Correct!' : 'Antwoord niet juist'}
              </span>
              <span className={`text-sm font-extrabold ${isCorrectState ? 'text-emerald-400' : 'text-rose-400'}`}>
                {isCorrectState ? 'Superb gedaan!' : 'Kijk goed op de Belgische kaart.'}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
