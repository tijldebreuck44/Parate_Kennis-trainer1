export interface GeoFeature {
  id: string;
  name: string;
  category: 'river' | 'mountain' | 'capital' | 'country' | 'province';
  coordinates?: [number, number]; // [lon, lat] for capital points / interaction anchors
  coordinatesList?: [number, number][]; // [lon, lat][] line path for rivers
  polygon?: [number, number][]; // Polygon coordinates for mountains/custom regions
}

// --- WORLD DATA ---

export const worldCapitals: GeoFeature[] = [
  { id: "wd-s-nyo", name: "New York", category: "capital", coordinates: [-74.006, 40.7128] }, // represent city coordinate
  { id: "wd-s-was", name: "Washington DC", category: "capital", coordinates: [-77.0369, 38.9072] },
  { id: "wd-l-can", name: "Ottawa", category: "capital", coordinates: [-75.6972, 45.4215] },
  { id: "wd-l-mex", name: "Mexico Stad", category: "capital", coordinates: [-99.1332, 19.4326] },
  { id: "wd-l-cub", name: "Havana", category: "capital", coordinates: [-82.3666, 23.1136] },
  { id: "wd-l-bra", name: "Brasilia", category: "capital", coordinates: [-47.9292, -15.7801] },
  { id: "wd-l-ven", name: "Caracas", category: "capital", coordinates: [-66.9036, 10.4806] },
  { id: "wd-l-col", name: "Bogota", category: "capital", coordinates: [-74.0721, 4.7110] },
  { id: "wd-l-per", name: "Lima", category: "capital", coordinates: [-77.0428, -12.0464] },
  { id: "wd-l-chi", name: "Santiago", category: "capital", coordinates: [-70.6693, -33.4489] },
  { id: "wd-l-arg", name: "Buenos Aires", category: "capital", coordinates: [-58.3816, -34.6037] },
  { id: "wd-l-egy", name: "Cairo", category: "capital", coordinates: [31.2357, 30.0444] },
  { id: "wd-l-alg", name: "Algiers", category: "capital", coordinates: [3.0588, 36.7538] },
  { id: "wd-l-lby", name: "Tripoli", category: "capital", coordinates: [13.1913, 32.8872] },
  { id: "wd-l-mar", name: "Rabat", category: "capital", coordinates: [-6.8498, 33.9716] },
  { id: "wd-l-tun", name: "Tunis", category: "capital", coordinates: [10.1815, 36.8065] },
  { id: "wd-l-som", name: "Mogadishu", category: "capital", coordinates: [45.3182, 2.0469] },
  { id: "wd-l-eth", name: "Addis Abeba", category: "capital", coordinates: [38.7578, 9.0192] },
  { id: "wd-l-sud", name: "Khartoem", category: "capital", coordinates: [32.5599, 15.5007] },
  { id: "wd-l-ken", name: "Nairobi", category: "capital", coordinates: [36.8219, -1.2921] },
  { id: "wd-l-rwa", name: "Kigali", category: "capital", coordinates: [30.0619, -1.9441] },
  { id: "wd-l-bur", name: "Gitega", category: "capital", coordinates: [29.9246, -3.4273] },
  { id: "wd-l-mli", name: "Bamako", category: "capital", coordinates: [-8.0026, 12.6392] },
  { id: "wd-l-nga", "name": "Abuja", category: "capital", coordinates: [7.4951, 9.0765] },
  { id: "wd-l-civ", "name": "Yamoussoukro", category: "capital", coordinates: [-5.2740, 6.8113] },
  { id: "wd-l-sen", "name": "Dakar", category: "capital", coordinates: [-17.4467, 14.6928] },
  { id: "wd-l-cod", "name": "Kinshasa", category: "capital", coordinates: [15.3101, -4.3276] },
  { id: "wd-l-zaf", "name": "Pretoria", category: "capital", coordinates: [28.1881, -25.7479] },
  { id: "wd-l-rus", "name": "Moskou", category: "capital", coordinates: [37.6173, 55.7558] },
  { id: "wd-l-ukr", "name": "Kiev", category: "capital", coordinates: [30.5234, 50.4501] },
  { id: "wd-l-pak", "name": "Islamabad", category: "capital", coordinates: [73.0479, 33.6844] },
  { id: "wd-l-afg", "name": "Kabul", category: "capital", coordinates: [69.2075, 34.5553] },
  { id: "wd-l-syr", "name": "Damascus", category: "capital", coordinates: [36.2913, 33.5138] },
  { id: "wd-l-isr", "name": "Jeruzalem", category: "capital", coordinates: [35.2137, 31.7683] },
  { id: "wd-l-idn", "name": "Jakarta", category: "capital", coordinates: [106.8456, -6.2115] },
  { id: "wd-l-phl", "name": "Manilla", category: "capital", coordinates: [120.9842, 14.5995] },
  { id: "wd-l-tha", "name": "Bangkok", category: "capital", coordinates: [100.5018, 13.7563] },
  { id: "wd-l-lbn", "name": "Beiroet", category: "capital", coordinates: [35.5018, 33.8938] },
  { id: "wd-l-jor", "name": "Amman", category: "capital", coordinates: [35.9284, 31.9454] },
  { id: "wd-l-sau", "name": "Riyad", category: "capital", coordinates: [46.7154, 24.7136] },
  { id: "wd-l-ind", "name": "New Delhi", category: "capital", coordinates: [77.2090, 28.6139] },
  { id: "wd-l-chn", "name": "Beijing", category: "capital", coordinates: [116.4074, 39.9042] },
  { id: "wd-l-jpn", "name": "Tokyo", category: "capital", coordinates: [139.6917, 35.6762] },
  { id: "wd-l-sgp", "name": "Singapore", category: "capital", coordinates: [103.8198, 1.3521] },
  { id: "wd-l-aus-country", "name": "Canberra", category: "capital", coordinates: [149.1300, -35.2809] },
  { id: "wd-l-nzl", "name": "Wellington", category: "capital", coordinates: [174.7762, -41.2865] }
];

export const worldRivers: GeoFeature[] = [
  {
    id: "wd-r-nijl",
    name: "Nijl",
    category: "river",
    coordinates: [31.5, 20.0],
    coordinatesList: [[31.2, 30.1], [32.5, 23.5], [32.5, 15.6], [31.5, 10.0], [33.5, 2.0]]
  },
  {
    id: "wd-r-amazone",
    name: "Amazone",
    category: "river",
    coordinates: [-60.0, -3.5],
    coordinatesList: [[-50.0, -0.1], [-55.0, -1.8], [-60.0, -3.4], [-65.0, -3.2], [-70.0, -4.5], [-73.5, -3.5]]
  },
  {
    id: "wd-r-mississippi",
    name: "Mississippi",
    category: "river",
    coordinates: [-91.0, 36.0],
    coordinatesList: [[-89.2, 29.1], [-91.2, 32.5], [-90.1, 38.6], [-92.5, 44.5], [-95.0, 47.0]]
  },
  {
    id: "wd-r-parana",
    name: "Paraná",
    category: "river",
    coordinates: [-52.0, -25.0],
    coordinatesList: [[-58.4, -34.6], [-60.7, -31.6], [-58.5, -27.4], [-54.6, -25.4], [-51.0, -20.0]]
  },
  {
    id: "wd-r-niger",
    name: "Niger",
    category: "river",
    coordinates: [2.0, 15.0],
    coordinatesList: [[6.2, 4.3], [6.5, 8.0], [4.5, 12.0], [0.1, 16.5], [-4.0, 16.0], [-8.0, 12.5]]
  },
  {
    id: "wd-r-kongo",
    name: "Kongo",
    category: "river",
    coordinates: [20.0, -1.0],
    coordinatesList: [[12.2, -6.1], [15.2, -4.3], [18.5, -0.5], [23.1, 0.5], [25.1, -1.5], [26.2, -5.0]]
  },
  {
    id: "wd-r-ob",
    name: "Ob",
    category: "river",
    coordinates: [75.0, 60.0],
    coordinatesList: [[73.0, 66.8], [70.0, 61.5], [78.0, 61.0], [82.0, 56.0], [85.0, 52.0]]
  },
  {
    id: "wd-r-jenisej",
    name: "Jenisej",
    category: "river",
    coordinates: [88.0, 60.5],
    coordinatesList: [[86.5, 71.5], [89.0, 65.0], [90.0, 56.0], [92.0, 52.0]]
  },
  {
    id: "wd-r-lena",
    name: "Lena",
    category: "river",
    coordinates: [122.0, 62.0],
    coordinatesList: [[126.5, 72.0], [123.0, 66.0], [120.0, 60.0], [105.0, 54.0]]
  },
  {
    id: "wd-r-huanghe",
    name: "Huanghe",
    category: "river",
    coordinates: [110.0, 38.0],
    coordinatesList: [[119.3, 37.8], [115.0, 36.0], [111.0, 35.5], [110.0, 40.0], [106.0, 37.0], [100.0, 36.0]]
  },
  {
    id: "wd-r-jangtsekiang",
    name: "Jangtsekiang",
    category: "river",
    coordinates: [112.0, 30.0],
    coordinatesList: [[121.5, 31.3], [118.5, 32.0], [115.0, 30.0], [112.0, 30.5], [104.5, 28.5], [99.0, 27.0]]
  },
  {
    id: "wd-r-ganges",
    name: "Ganges",
    category: "river",
    coordinates: [84.0, 25.0],
    coordinatesList: [[89.5, 22.5], [88.0, 24.0], [85.0, 25.5], [80.0, 28.5], [78.5, 30.5]]
  },
  {
    id: "wd-r-darling",
    name: "Darling",
    category: "river",
    coordinates: [142.0, -32.0],
    coordinatesList: [[139.0, -34.0], [141.5, -32.5], [144.5, -30.0], [148.0, -28.0]]
  }
];

export const worldMountains: GeoFeature[] = [
  {
    id: "wd-m-himalaya",
    name: "Himalaya",
    category: "mountain",
    coordinates: [85.0, 28.5],
    polygon: [[75.0, 33.0], [85.0, 28.0], [95.0, 27.0], [92.0, 25.0], [82.0, 26.0], [75.0, 33.0]]
  },
  {
    id: "wd-m-andes",
    name: "Andes",
    category: "mountain",
    coordinates: [-70.0, -20.0],
    polygon: [[-72.0, 10.0], [-74.0, -5.0], [-71.0, -20.0], [-68.0, -35.0], [-73.0, -52.0], [-70.0, -52.0], [-66.0, -35.0], [-68.0, -20.0], [-71.0, -5.0], [-70.0, 10.0]]
  },
  {
    id: "wd-m-rocky",
    name: "Rocky Mountains",
    category: "mountain",
    coordinates: [-110.0, 42.0],
    polygon: [[-122.0, 58.0], [-115.0, 50.0], [-108.0, 38.0], [-105.0, 36.0], [-109.0, 35.0], [-114.0, 43.0], [-118.0, 52.0], [-122.0, 58.0]]
  },
  {
    id: "wd-m-atlas",
    name: "Atlas",
    category: "mountain",
    coordinates: [-5.0, 32.0],
    polygon: [[-9.0, 30.0], [-5.0, 32.0], [1.0, 34.0], [5.0, 35.0], [7.0, 36.0], [4.0, 34.0], [-2.0, 32.0], [-9.0, 30.0]]
  },
  {
    id: "wd-m-madre",
    name: "Sierra Madre",
    category: "mountain",
    coordinates: [-102.0, 22.0],
    polygon: [[-108.0, 28.0], [-105.0, 23.0], [-99.0, 18.0], [-95.0, 16.0], [-98.0, 15.0], [-102.0, 19.0], [-107.0, 25.0], [-108.0, 28.0]]
  },
  {
    id: "wd-m-oeral",
    name: "Oeral",
    category: "mountain",
    coordinates: [60.0, 60.0],
    polygon: [[59.0, 68.0], [60.0, 62.0], [59.0, 55.0], [61.0, 51.0], [62.0, 55.0], [61.0, 62.0], [61.0, 68.0], [59.0, 68.0]]
  }
];

// --- EUROPE DATA ---

export const europeCapitals: GeoFeature[] = [
  { id: "eu-l-ned", name: "Amsterdam", category: "capital", coordinates: [4.9041, 52.3676] },
  { id: "eu-l-bel", name: "Brussel", category: "capital", coordinates: [4.3517, 50.8503] },
  { id: "eu-l-lux", name: "Luxemburg", category: "capital", coordinates: [6.1296, 49.8153] },
  { id: "eu-l-fra", name: "Parijs", category: "capital", coordinates: [2.3522, 48.8566] },
  { id: "eu-l-dui", name: "Berlijn", category: "capital", coordinates: [13.4050, 52.5200] },
  { id: "eu-l-gbr", name: "Londen", category: "capital", coordinates: [-0.1278, 51.5074] },
  { id: "eu-l-ier", name: "Dublin", category: "capital", coordinates: [-6.2603, 53.3498] },
  { id: "eu-l-ita", name: "Rome", category: "capital", coordinates: [12.4964, 41.9028] },
  { id: "eu-l-spa", name: "Madrid", category: "capital", coordinates: [-3.7492, 40.4637] },
  { id: "eu-l-por", name: "Lissabon", category: "capital", coordinates: [-9.1393, 38.7223] },
  { id: "eu-l-pol", name: "Warschau", category: "capital", coordinates: [21.0122, 52.2297] },
  { id: "eu-l-tsj", name: "Praag", category: "capital", coordinates: [14.4378, 50.0755] },
  { id: "eu-l-slo", name: "Bratislava", category: "capital", coordinates: [17.1077, 48.1486] },
  { id: "eu-l-hon", name: "Boedapest", category: "capital", coordinates: [19.0402, 47.4979] },
  { id: "eu-l-kro", name: "Zagreb", category: "capital", coordinates: [15.9819, 45.8150] },
  { id: "eu-l-slv", name: "Ljubljana", category: "capital", coordinates: [14.5058, 46.0569] },
  { id: "eu-l-ser", name: "Belgrado", category: "capital", coordinates: [20.4489, 44.7866] },
  { id: "eu-l-mon", name: "Podgorica", category: "capital", coordinates: [19.2636, 42.4304] },
  { id: "eu-l-kos", name: "Pristina", category: "capital", coordinates: [21.1655, 42.6629] },
  { id: "eu-l-alb", name: "Tirana", category: "capital", coordinates: [19.8187, 41.3275] },
  { id: "eu-l-bos", name: "Sarajevo", category: "capital", coordinates: [18.4131, 43.8563] },
  { id: "eu-l-nma", name: "Skopje", category: "capital", coordinates: [21.4280, 41.9981] },
  { id: "eu-l-gri", name: "Athene", category: "capital", coordinates: [23.7275, 37.9838] },
  { id: "eu-l-bul", name: "Sofia", category: "capital", coordinates: [23.3219, 42.6977] },
  { id: "eu-l-roe", name: "Boekarest", category: "capital", coordinates: [26.1025, 44.4268] },
  { id: "eu-l-mol", name: "Chisinau", category: "capital", coordinates: [28.8638, 47.0105] },
  { id: "eu-l-oek", name: "Kiev", category: "capital", coordinates: [30.5234, 50.4501] },
  { id: "eu-l-wit", name: "Minsk", category: "capital", coordinates: [27.5615, 53.9006] },
  { id: "eu-l-lit", name: "Vilnius", category: "capital", coordinates: [25.2797, 54.6872] },
  { id: "eu-l-let", name: "Riga", category: "capital", coordinates: [24.1052, 56.9496] },
  { id: "eu-l-est", name: "Tallinn", category: "capital", coordinates: [24.7535, 59.4370] },
  { id: "eu-l-rus", name: "Moskou", category: "capital", coordinates: [37.6173, 55.7558] },
  { id: "eu-l-mal", name: "Valletta", category: "capital", coordinates: [14.5146, 35.8989] },
  { id: "eu-l-cyp", name: "Nicosia", category: "capital", coordinates: [33.3823, 35.1856] },
  { id: "eu-l-oas", name: "Wenen", category: "capital", coordinates: [16.3738, 48.2082] },
  { id: "eu-l-zwi-capital", name: "Bern", category: "capital", coordinates: [7.4474, 46.9480] },
  { id: "eu-l-dan", name: "Kopenhagen", category: "capital", coordinates: [12.5683, 55.6761] },
  { id: "eu-l-noo", name: "Oslo", category: "capital", coordinates: [10.7522, 59.9139] },
  { id: "eu-l-zwe", name: "Stockholm", category: "capital", coordinates: [18.0686, 59.3293] },
  { id: "eu-l-fin", name: "Helsinki", category: "capital", coordinates: [24.9384, 60.1699] },
  { id: "eu-l-ijsl", name: "Reykjavik", category: "capital", coordinates: [-21.9426, 64.1466] }
];

export const europeRivers: GeoFeature[] = [
  {
    id: "eu-r-rijn",
    name: "Rijn",
    category: "river",
    coordinates: [8.0, 50.0],
    coordinatesList: [[6.0, 51.9], [7.6, 50.4], [8.3, 49.0], [7.6, 47.6], [9.1, 46.8]]
  },
  {
    id: "eu-r-donau",
    name: "Donau",
    category: "river",
    coordinates: [19.0, 46.5],
    coordinatesList: [[29.0, 45.2], [27.0, 44.3], [22.5, 44.4], [20.2, 44.8], [19.0, 47.5], [16.5, 48.2], [12.1, 49.0], [9.0, 48.0]]
  },
  {
    id: "eu-r-seine",
    name: "Seine",
    category: "river",
    coordinates: [1.5, 49.0],
    coordinatesList: [[0.2, 49.4], [1.5, 49.2], [2.3, 48.8], [3.5, 48.2], [4.8, 47.5]]
  },
  {
    id: "eu-r-wolga",
    name: "Wolga",
    category: "river",
    coordinates: [46.0, 51.0],
    coordinatesList: [[48.0, 46.0], [44.8, 48.7], [46.0, 51.5], [49.0, 53.0], [49.0, 56.0], [41.0, 56.5], [34.0, 57.0]]
  },
  {
    id: "eu-r-loire",
    name: "Loire",
    category: "river",
    coordinates: [-1.5, 47.2],
    coordinatesList: [[-2.2, 47.3], [1.0, 47.8], [2.5, 47.4], [3.5, 46.5], [3.9, 44.5]]
  },
  {
    id: "eu-r-oder",
    name: "Oder",
    category: "river",
    coordinates: [14.5, 52.5],
    coordinatesList: [[14.6, 53.8], [14.2, 52.8], [14.8, 52.0], [17.0, 51.1], [18.0, 49.8]]
  },
  {
    id: "eu-r-dnjepr",
    name: "Dnjepr",
    category: "river",
    coordinates: [32.0, 48.0],
    coordinatesList: [[32.2, 46.5], [35.0, 47.8], [31.0, 50.5], [30.1, 52.3], [32.1, 54.8]]
  },
  {
    id: "eu-r-theems",
    name: "Theems",
    category: "river",
    coordinates: [0.0, 51.5],
    coordinatesList: [[1.0, 51.5], [0.5, 51.5], [-0.1, 51.5], [-1.0, 51.6], [-2.0, 51.7]]
  },
  {
    id: "eu-r-po",
    name: "Po",
    category: "river",
    coordinates: [10.5, 45.0],
    coordinatesList: [[12.5, 44.9], [11.5, 45.0], [9.5, 45.1], [7.5, 44.8]]
  },
  {
    id: "eu-r-ebro",
    name: "Ebro",
    category: "river",
    coordinates: [-0.5, 41.5],
    coordinatesList: [[0.8, 40.7], [-0.5, 41.3], [-1.5, 42.0], [-4.0, 43.0]]
  },
  {
    id: "eu-r-rhone",
    name: "Rhône",
    category: "river",
    coordinates: [4.8, 44.5],
    coordinatesList: [[4.8, 43.3], [4.8, 45.7], [6.0, 46.2], [7.5, 46.1], [8.0, 46.5]]
  },
  {
    id: "eu-r-taag",
    name: "Taag",
    category: "river",
    coordinates: [-6.8, 39.5],
    coordinatesList: [[-9.1, 38.7], [-8.0, 39.4], [-6.5, 39.7], [-4.0, 39.9], [-2.0, 40.5]]
  },
  {
    id: "eu-r-elbe",
    name: "Elbe",
    category: "river",
    coordinates: [11.5, 52.0],
    coordinatesList: [[8.7, 53.9], [10.0, 53.5], [12.0, 51.8], [14.0, 50.8], [15.5, 50.2]]
  }
];

export const europeMountains: GeoFeature[] = [
  {
    id: "eu-m-pyreneen",
    name: "Pyreneeën",
    category: "mountain",
    coordinates: [0.5, 42.6],
    polygon: [[-2.0, 43.3], [0.5, 42.8], [3.0, 42.5], [2.0, 42.0], [-1.0, 42.5], [-2.0, 43.3]]
  },
  {
    id: "eu-m-alpen",
    name: "Alpen",
    category: "mountain",
    coordinates: [10.0, 46.0],
    polygon: [[6.0, 44.0], [7.0, 46.0], [10.0, 47.0], [14.0, 47.5], [15.0, 46.5], [11.5, 45.8], [8.0, 44.7], [6.0, 44.0]]
  },
  {
    id: "eu-m-karpaten",
    name: "Karpaten",
    category: "mountain",
    coordinates: [23.0, 47.0],
    polygon: [[18.0, 49.5], [20.0, 49.0], [24.0, 48.0], [26.0, 46.0], [25.0, 45.0], [22.0, 45.0], [24.0, 46.5], [22.0, 48.0], [18.0, 49.5]]
  },
  {
    id: "eu-m-scandinavisch",
    name: "Scandinavisch Hoogland",
    category: "mountain",
    coordinates: [12.0, 62.0],
    polygon: [[6.0, 59.0], [8.0, 62.0], [14.0, 65.0], [19.0, 68.0], [22.0, 69.0], [16.0, 66.0], [11.0, 62.0], [6.0, 59.0]]
  },
  {
    id: "eu-m-kaukasus",
    name: "Kaukasus",
    category: "mountain",
    coordinates: [43.0, 43.0],
    polygon: [[38.0, 44.0], [42.0, 43.0], [48.0, 41.0], [46.0, 40.0], [41.0, 42.0], [38.0, 44.0]]
  }
];

// --- BELGIUM DATA ---

export const belgiumRivers: GeoFeature[] = [
  {
    id: "be-r-ijz",
    name: "IJzer",
    category: "river",
    coordinates: [2.65, 51.0],
    coordinatesList: [[2.54, 51.10], [2.65, 51.05], [2.75, 50.95], [2.60, 50.85]]
  },
  {
    id: "be-r-sch",
    name: "Schelde",
    category: "river",
    coordinates: [3.9, 51.0],
    coordinatesList: [[4.30, 51.35], [4.40, 51.25], [3.95, 51.05], [3.70, 51.05], [3.60, 50.80], [3.40, 50.50]]
  },
  {
    id: "be-r-maa",
    name: "Maas",
    category: "river",
    coordinates: [5.1, 50.45],
    coordinatesList: [[5.70, 51.20], [5.60, 50.85], [5.10, 50.45], [4.85, 50.45], [4.90, 50.25], [4.80, 50.00]]
  },
  {
    id: "be-r-lei",
    name: "Leie",
    category: "river",
    coordinates: [3.45, 50.85],
    coordinatesList: [[3.70, 51.05], [3.45, 50.85], [3.20, 50.70]]
  },
  {
    id: "be-r-samber",
    name: "Samber",
    category: "river",
    coordinates: [4.4, 50.4],
    coordinatesList: [[4.85, 50.45], [4.40, 50.40], [4.15, 50.30]]
  }
];
